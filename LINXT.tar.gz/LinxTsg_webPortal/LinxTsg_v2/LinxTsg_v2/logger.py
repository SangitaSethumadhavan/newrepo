'''
	
'''
import os
import logging

from .settings import BASE_DIR
from .settings import DEBUG

# Usage in other modules:
#
#     from LinxTsg_v2.logger import log
#     log.info('some output')
#
# Note, doing this manually in other modules results in nicer output:
#
#     import logging
#     log = logging.getLogger(__name__)
#     log.info('some output')

# the basic logger LinxTsg_v2 can import
log = logging.getLogger(__name__)
linxt_log = logging.getLogger('linxt_log')
auth_log = logging.getLogger('auth_log')
# the minimum reported level
if DEBUG:
    min_level = 'DEBUG'
else:
    min_level = 'INFO'

# the minimum reported level for LinxTsg_v2's modules
# optionally set to DEBUG to see database queries etc.
# or set to min_level to control it using the DEBUG flag
min_django_level = 'INFO'

# logging dictConfig configuration
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,  # keep LinxTsg_v2's default loggers #linxt_log
    'formatters': {
        # see full list of attributes here: format for log data
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        },
        'timestampthread': {
            'format': "%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s] [%(name)-20.20s]  %(message)s",
        },
		'db': {
            'format': '[%(levelname)s - %(created)s] %(duration)s %(sql)s %(params)s'
        },
    },
    'handlers': {
        'logfile': {
            # optionally raise to INFO to not fill the log file too quickly
            'level': min_level,  # this level or higher goes to the log file
            'class': 'logging.handlers.RotatingFileHandler',
            # IMPORTANT: replace with your desired logfile name!
            'filename': os.path.join(BASE_DIR+'/LinxWebapp/linxt_log', 'applog.log'),
            'maxBytes': 50 * 10**6,  # will 50 MB do?
            'backupCount': 3,  # keep this many extra historical files
            'formatter': 'timestampthread'
        },
		# log for LinxWebapp related 
		'linxt_log': {
            # optionally raise to INFO to not fill the log file too quickly
            'level': min_level,  # this level or higher goes to the log file
            'class': 'logging.handlers.RotatingFileHandler',
            # IMPORTANT: replace with your desired logfile name!
            'filename': os.path.join(BASE_DIR+'/LinxWebapp/linxt_log', 'LinxTsg.log'),
            'maxBytes': 50 * 10**6,  # will 50 MB do?
            'backupCount': 3,  # keep this many extra historical files
            'formatter': 'timestampthread'
        },
		#authentication
		'auth_log': {
            # optionally raise to INFO to not fill the log file too quickly
            'level': min_level,  # this level or higher goes to the log file
            'class': 'logging.handlers.RotatingFileHandler',
            # IMPORTANT: replace with your desired logfile name!
            'filename': os.path.join(BASE_DIR+'/LinxWebapp/linxt_log', 'auth_log.log'),
            'maxBytes': 50 * 10**6,  # will 50 MB do?
            'backupCount': 3,  # keep this many extra historical files
            'formatter': 'timestampthread'
        },
        'console': {
            'level': min_level,  # this level or higher goes to the console
            'class': 'logging.StreamHandler',
        },
		# log for LinxWebapp mysql related 
		'db_log': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'formatter': 'db',
            'maxBytes': 50 * 10**6,
            'backupCount': 3,
            'filename': os.path.join(BASE_DIR+'/LinxWebapp/linxt_log', 'LinxTsg_db.log')
        }
    },
    'loggers': {
        'linxt_log': {  # configure all of LinxWebapp
            'handlers': ['linxt_log','console'],
            'level': min_django_level,  # this level or higher goes to the console
            'propagate': False,  # don't propagate further, to avoid duplication
        },
        # root configuration � for LinxWebapp database related logs
        '': {
            'handlers': ['logfile', 'console'],
            'level': min_level,  # this level or higher goes to the console,
        },
		'db_log': {  # configure all of LinxWebapp database related logs
            'handlers': ['db_log','console'],
            'level': min_django_level,  # this level or higher goes to the console
            'propagate': False,  # don't propagate further, to avoid duplication
        },
		'auth_log': {  # configure all of LinxWebapp authentication related logs
            'handlers': ['auth_log','console'],
            'level': min_django_level,  # this level or higher goes to the console
            'propagate': False,  # don't propagate further, to avoid duplication
        },
    },
}