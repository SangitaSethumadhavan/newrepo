from django.apps import AppConfig


class LinxwebappConfig(AppConfig):
	name = 'LinxWebapp'
	
	def ready(self):
		import LinxWebapp.signals 