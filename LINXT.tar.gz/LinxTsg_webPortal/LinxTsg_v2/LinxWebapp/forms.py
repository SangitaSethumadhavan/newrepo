from django import forms
from .models import *
from django.db.models import Q
from django.utils.translation import gettext_lazy as _


def get_model_choices():
	choices = [('', 'Select Model'),('Model A', 'Model A'),('Model B', 'Model B')] 
	return choices
	
def get_account_type_choices():
	choices = [('', 'Select Type'),('FPP', 'FPP'),('T & M', 'T & M')]  
	return choices

def get_support_model_choices():
	choices = [('', 'Select Support Model'),('ODC', 'ODC'),('GCC', 'GCC')]  
	return choices

def get_os_choices():
	os = OSData.objects.order_by('os').values_list('os', flat = True).distinct()
	os_choices = [('', 'Select OS')] + [(id, id) for id in os]
	return os_choices

def get_acc_choices():
	acc = AccountData.objects.order_by('acc_name').values_list('acc_name', flat = True).distinct()
	acc_choices = [('', 'Select Account')] + [(id, id) for id in acc]
	return acc_choices
	
class Access_Request_Form(forms.Form):
	'''
		Access_Request_Form
	'''
	user_email = forms.CharField(label=_('Email Address'),widget=forms.EmailInput(attrs={'id':'register-email','class': 'input-material','required': 'true','data-msg': 'Please enter a valid email address with domain'}))
	user_adid = forms.CharField(label=_('ADID'),widget=forms.TextInput(attrs={'id':'register-username','class': 'input-material','required': 'true','data-msg': 'Please enter your ADID'}))
	
	@property
	def field_order(self):
		return ['user_adid', 'user_email']
		
class ApprovalForm(forms.ModelForm):
	'''
		Approval Form for Approve and edit user request
	'''
	class Meta:
		model = AccessRequest
		fields = ('user_email','user_type',)
	 
	def __init__(self, *args, **kwargs):
		super(ApprovalForm, self).__init__(*args, **kwargs)
		self.fields['user_type'] = forms.ChoiceField(choices=[('', 'Select Type'),('Admin', 'Admin'),('User', 'User')])

		
class Login_form(forms.Form):
	'''
		Login Form
	'''
	username = forms.CharField(label=_('Username'),widget=forms.TextInput(attrs={'id':'login-username','ata-msg':'Please enter your username','required': 'true','class':'input-material'}),help_text='Login with your Wipro ADID/ADID@wipro.com')
	password = forms.CharField(widget = forms.PasswordInput(attrs={'id':'login-username','ata-msg':'Please enter your password" class="input-material','required': 'true','class':'input-material'}))
	
	@property
	def field_order(self):
		return ['username', 'password']
	
	def clean_username(self):
		username = self.cleaned_data['username']
		if username == "admin@wipro.com" or username == "user@wipro.com":
			return username
		else:
			user = AccessRequest.objects.filter(Q(user_adid=username) | Q(user_addom=username)).first()
			if not user:
				raise ValidationError(_('You entered an invalid email address or username.'))
			self.user_cache = user
			return username
			
			
class Account_form(forms.ModelForm):
	'''
		Form for add or update account data 
	'''
	class Meta:
		model = AccountData
		fields = ('acc_name','acc_model','acc_type','acc_support_model','acc_vertical','acc_location','acc_geo',)
		
	def __init__(self, *args, **kwargs):
		super(Account_form, self).__init__(*args, **kwargs)
		self.fields['acc_model'] = forms.ChoiceField(choices=get_model_choices())
		self.fields['acc_type'] = forms.ChoiceField(choices=get_account_type_choices() )
		self.fields['acc_support_model'] = forms.ChoiceField(choices=get_support_model_choices())

		
		
class Server_form(forms.ModelForm):
	'''
		Form for add or update account data 
	'''
	class Meta:
		model = ServerData
		fields = ('acc_name','os','version_name','server_count',)
		
		
class OS_form(forms.ModelForm):
	'''
		Form for add OS
	'''
	class Meta:
		model = OSData
		fields = ('os_type','os','architecture',)
		
	def __init__(self, *args, **kwargs):
		super(OS_form, self).__init__(*args, **kwargs)
		self.fields['os_type'] = forms.ChoiceField(choices=[('', 'Select Type'),('Linux', 'Linux'),('UNIX', 'UNIX')]  )

		
class OS_Varient_form(forms.ModelForm):		
	'''
		Form for add OS Varient
	'''
	
	class Meta:
		model = OSVarient
		fields = ('os','os_varient','varient_version',)
		
	def __init__(self, *args, **kwargs):
		super(OS_Varient_form, self).__init__(*args, **kwargs)
		self.fields['os'] = forms.ChoiceField(choices=get_os_choices)
		
		

#category
class Category_form(forms.ModelForm):
	'''
		Form for add Category
	'''
	class Meta:
		model = CategoryData
		fields = ('category',)
		
#Automation method
class Automation_method_form(forms.ModelForm):
	'''
		Form for add Automation Method Data
	'''
	class Meta:
		model = AutomationMethodData
		fields = ('method',)
		
#SLA
class SLA_form(forms.ModelForm):
	'''
		Form for add SLA
	'''
	class Meta:
		model = SLAData
		fields = ('sla',)
		
class TsgAssessUploadForm(forms.ModelForm):
	uploaded_file = forms.FileField(label='Upload File',widget=forms.ClearableFileInput(attrs={'class':'form-control'}),)
	title = forms.CharField(widget=forms.TextInput(attrs={'readonly':'true','class':'form-control'}))
	acc_name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
	data_provider = forms.CharField(widget=forms.TextInput(attrs={'readonly':'true','class':'form-control'}))
	 
	class Meta:
		model = TsgAssessUpload
		fields = ('acc_name','uploaded_file','title','data_provider',)
		
class DocumentUploadForm(forms.ModelForm):
	uploaded_file = forms.FileField(label='Upload File',widget=forms.ClearableFileInput(attrs={'class':'form-control'}),)
	title = forms.CharField(widget=forms.TextInput(attrs={'readonly':'true','class':'form-control'}))
	acc_name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control'}))
	data_provider = forms.CharField(widget=forms.TextInput(attrs={'readonly':'true','class':'form-control'}))
	 
	class Meta:
		model = AccountDocumentUpload
		fields = ('acc_name','uploaded_file','title','data_provider',)		


class AccountChoiceForm(forms.Form):
	fields = ('account')
	def __init__(self, *args, **kwargs):
		super(AccountChoiceForm, self).__init__(*args, **kwargs)
		self.fields['account'] = forms.ChoiceField(choices=get_acc_choices(), widget=forms.Select(attrs={'class':'form-control pageacc selectpicker ','data-live-search':'true'}) )
		
class EmrUploadForm(forms.ModelForm):
	uploaded_file = forms.FileField(label='Upload File',widget=forms.ClearableFileInput(attrs={'class':'form-control'}),)
	title = forms.CharField(widget=forms.TextInput(attrs={'readonly':'true','class':'form-control'}))
	data_provider = forms.CharField(widget=forms.TextInput(attrs={'readonly':'true','class':'form-control'}))
	class Meta:
		model = EmrUpload
		fields = ('uploaded_file','title','data_provider',)