$(function () { 
   datatable();
   var saveForm = function () {
								var form = $(this);
								$.ajax({
									  url: form.attr("action"),
									  data: form.serialize(),
									  type: form.attr("method"),
									  dataType: 'json',
									  success: function (data) {
										 if(data.form_is_valid)
										 {
											toastr["success"](data.message)
											$(".account_add").html('')
											$(".account_add").append(data.account_add_form)
										 }
										 else{
											toastr["error"](data.message)
										 }
										datatable();
									  }
								}); 
								return false;
							  };
	$(".account_add").on("submit", ".add_account", saveForm);	
	var upload = function(event) {
			event.preventDefault();
			var data = new FormData($('.upload_account').get(0));
			var data_provider = $("#id_data_provider").val();
			$.ajax({
				url: $(this).attr('action'),
				type: $(this).attr('method'),
				data: data,
				cache: false,
				processData: false,
				contentType: false,
				success: function(data) {
					 if(data.form_is_valid)
										 {
											toastr["success"](data.message)
											$(".account_upload").html('')
											$(".account_upload").append(data.account_upload_form)
											$("#id_data_provider").val('');
											$("#id_data_provider").val(data_provider);
											$('input[type="file"]').change(function(e){
												var fileName = e.target.files[0].name;
												$("#id_title").val(fileName);
											}); 
										 }
										 else{
											toastr["error"](data.message)
										 }
										 datatable();
				}
			}); 
			return false;
			}
	
	
	$(".account_upload").on("submit", ".upload_account", upload);

	
});


function datatable(){
	
	var e= $("#datatable1").DataTable({
		
										responsive:{details:!1},
										"processing" : true,
										lengthMenu: [
											[ 5, 25, 50, -1 ],
											[ '5', '25', '50', 'Show all' ]
										],									
										"ajax" :"accounts/linux_uploaded_info",
										"columns" : [
										{"data" : "ref_id"},
										{"data" : "title"},
										{"data" : "data_provider"},
										{"data" : "uploaded_date"},
										{
											 data: null,
											 className: "center",render: function ( data, type, row ) {
														return '<a href="'+data.uploaded_file+'" class="btn btn-info "> <i class="fa fa-download"></i> <span></span> </a>	'
														} 
										}
										]
									});
	
	$(document).on("sidebarChanged",function(){e.columns.adjust(),e.responsive.recalc(),e.responsive.rebuild()})
}