$(function () { 
		datatable();
	    Messenger.options={
						extraClasses:"messenger-fixed messenger-on-top  messenger-on-right",theme:"flat",messageDefaults:{
						showCloseButton:!0}
					}
	   var loadForm = function () {
			var btn = $(this);
			$.ajax({
			  url: btn.attr("data-url"),
			  type: 'get',
			  dataType: 'json',
			  beforeSend: function () {
				$("#addmodal").modal("show");
			  },
			  success: function (data) {
				$("#addmodal .modal-content").html(data.html_form);
			  }
			});
		  };

				
	    var saveForm = function () {
								var form = $(this);
								$.ajax({
									  url: form.attr("action"),
									  data: form.serialize(),
									  type: form.attr("method"),
									  dataType: 'json',
									  success: function (data) {
										 if(data.form_is_valid)
										 {
											Messenger().post({message:data.message,type:"success"})
											$("#addmodal").modal("hide");
										 }
										 else{
											Messenger().post({message:data.message,type:"error"})
										 }
										$('#datatable1').DataTable().destroy();
										datatable();
									  }
								}); 
								return false;
							  };
	$(".add_os_varient").click(loadForm);
	$("#addmodal").on("submit", ".form_add_os_varient", saveForm);
	
	$("#datatable1").on("click", ".js-update-os-varient", loadForm);
	$("#addmodal").on("submit", ".js-os-varient-update-form", saveForm);
  
	$("#datatable1").on("click", ".js-delete-os-varient", loadForm);
	$("#addmodal").on("submit", ".js-os-varient-delete-form", saveForm);

	});

	
function datatable(){

	var e= $("#datatable1").DataTable({
										responsive:{details:!1},
										"processing" : true,
										lengthMenu: [
											[ 5, 25, 50, -1 ],
											[ '5', '25', '50', 'Show all' ]
										],									
										"ajax" :"os_varient_info/getosvarientdata/",
										"columns" : [
										{"data" : "ref_id"},
										{"data" : "os"},
										{"data" : "os_varient"},
										{"data" : "varient_version"},
										{"data" : "version_name"},
										{"data" : "added_on"},
										{"data" : "added_by"},
										{
											 data: null,
											 className: "center",render: function ( data, type, row ) {
											// Combine the first and last names into a single table field
											return '<button type="button" class="btn btn-icon waves-effect waves-light m-b-5 js-update-os-varient" style=" background: none; color: #f9c851; " data-url="os_varient_info/'+data.os_id+'/update/"><i class="fa fa-pencil"></i></button><button type="button" class="btn btn-icon waves-effect waves-light  m-b-5 js-delete-os-varient" style=" background: none; color: red; " data-url="os_varient_info/'+data.os_id+'/delete/"><i class="fa fa-trash"></i> </button>'
											} 
										},	
										]
									});
	
	$(document).on("sidebarChanged",function(){e.columns.adjust(),e.responsive.recalc(),e.responsive.rebuild()})
}