$(document).ready(function(){
		
			$('[data-toggle="tooltip"]').tooltip();
			//var actions = $("table td:last-child").html();
			var actions = '<a class="server_add" title="Add" data-toggle="tooltip"><i class="fa fa-save"></i></a><a class="server_edit" title="Edit" data-toggle="tooltip"><i class="fa fa-pencil"></i></a><a class="server_delete" title="Delete" data-toggle="tooltip"><i class="fa fa-trash"></i></a>';
			// Append table with add row form on add new button click

			$(".add-new-server").click(function(){
				$(this).attr("disabled", "disabled");
				var index = $(".server_table tbody tr:last-child").index();
				var os_types_str = $("#os_types_str").text();
				var typeArray = os_types_str.split(',');
				var typeStr = ''
					for(var i = 0; i<typeArray.length;i++)
					{
							typeStr += '<option>'+typeArray[i]+'</option>' 
					}		
				var row = '<tr>' +
					'<td>'+
						'<select name="os_type" class="form-control mb-3 mb-3 os_type_data" required="" id="os_type">'+
							'<option value="Select OS Type" selected="">Select OS Type</option>'+typeStr+'</select>'+
					'</td>'+
					'<td>'+
						'<select name="os_varient" class="form-control mb-3 mb-3 os_varient" required="" id="os_varient"><option value="Select OS Varient" selected="">Select OS Varient</option></select>'+
					'</td>' +
					'<td>'+
						'<select name="os_version" class="form-control mb-3 mb-3 os_version" required="" id="os_version"><option value="Select OS Version" selected="">Select OS Version</option></select>'+
					'</td>' +
					'<td><input type="text" class="form-control" name="server_count" id="server_count" value="0"></td>' +
					'<td>' + actions + '</td>' +
				'</tr>';
				$(".server_table").append(row);		
				$(".server_table tbody tr").eq(index + 1).find(".server_add, .server_edit").toggle();
				$('[data-toggle="tooltip"]').tooltip(); 
			});
			

			// Delete row on delete button click
			$(document).on("click", ".server_delete", function(){			
				$('[data-toggle="tooltip"]').tooltip("hide");
				$(this).parents("tr").remove();
				$(".add-new-server").removeAttr("disabled");
			});

			
			
			
			
			//RISK REGISTER
			
			var risk_actions = '<a class="risk_add" title="Add" data-toggle="tooltip"><i class="fa fa-save"></i></a><a class="risk_edit" title="Edit" data-toggle="tooltip"><i class="fa fa-pencil"></i></a><a class="risk_delete" title="Delete" data-toggle="tooltip"><i class="fa fa-trash"></i></a>';
			// Append table with add row form on add new button click

			$(".add-new-risk").click(function(){
				$(this).attr("disabled", "disabled");
				var index = $(".risk_table tbody tr:last-child").index();
	
				var row = '<tr>' +
					'<td><input type="text" class="form-control" name="risk_identified" id="risk_identified" placeholder="Risk Identified"></td>'+
					'<td><input type="text" class="form-control input-datepicker" name="identified_date" id="identified_date" placeholder="Identified Date"></td>' +
					'<td><input type="text" class="form-control input-datepicker" name="closure_date" id="closure_date" placeholder="Closure Date"></td>'+
					'<td>'+
						'<select name="status" class="form-control mb-3 mb-3" required="" id="status">'+
							'<option value="" selected="">Select Status</option>'+
							'<option>Completed</option>'+
							'<option>Pending</option>'+
						'</select>'+
					'</td>' +
					'<td><input type="text" class="form-control" name="remarks" id="remarks" placeholder="Remarks"></td>' +
					'<td>' + risk_actions + '</td>' +
				'</tr>';
				
				$(".risk_table").append(row);		
				$(".input-datepicker").datepicker({autoclose:!0,format:"yyyy-mm-dd"})
				$(".risk_table tbody tr").eq(index + 1).find(".risk_add, .risk_edit").toggle();
				$('[data-toggle="tooltip"]').tooltip();
			});
			
			// Edit row on edit button click
			$(document).on("click", ".risk_edit", function(){	
				var currentTD = $(this).parents('tr').find('td').eq(0).html(); 
				if(currentTD === 'Risk Identified'){
					$(this).parents('tr').find('td').eq(0).html('<input type="text" class="form-control" name="risk_identified" id="risk_identified" placeholder="' + currentTD + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(0).html('<input type="text" class="form-control" name="risk_identified" id="risk_identified" value="' + currentTD + '">');
				}
				
				
				var identified_date = $(this).parents('tr').find('td').eq(1).html(); 
				if(identified_date === 'Identified Date'){
					$(this).parents('tr').find('td').eq(1).html('<input type="text" class="form-control input-datepicker" name="identified_date" id="identified_date" placeholder="' + identified_date + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(1).html('<input type="text" class="form-control input-datepicker" name="identified_date" id="identified_date" value="' + identified_date + '">');
				}
				
				
				var closure_date = $(this).parents('tr').find('td').eq(2).html();  
				if(closure_date === 'Closure Date'){
					$(this).parents('tr').find('td').eq(2).html('<input type="text" class="form-control input-datepicker" name="closure_date" id="closure_date" placeholder="' + closure_date + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(2).html('<input type="text" class="form-control input-datepicker" name="closure_date" id="closure_date" value="' + closure_date + '">');
				}
				
				
				var currentTD = $(this).parents('tr').find('td').eq(3).html(); 

				var typeArray = ['Completed','Pending']
				var typeStr = '<option value="">Select Status</option>'
				for(var i = 0; i<typeArray.length;i++)
				{
					if(currentTD == typeArray[i])
					{
						typeStr += '<option selected>'+currentTD+'</option>'
					}
					else
					{
						typeStr += '<option>'+typeArray[i]+'</option>' 
					}
				}
				$(".input-datepicker").datepicker({autoclose:!0,format:"yyyy-mm-dd"})
				$(this).parents('tr').find('td').eq(3).html('<select name="status" class="form-control mb-3 mb-3 status" required="" id="status">'+typeStr+'</select>');
				
				
				var remarks = $(this).parents('tr').find('td').eq(4).html(); 
				
				if(remarks === 'Remarks'){
					$(this).parents('tr').find('td').eq(4).html('<input type="text" class="form-control" name="remarks" id="remarks" placeholder="' + remarks + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(4).html('<input type="text" class="form-control" name="remarks" id="remarks" value="' + remarks + '">');
				}
				$(this).parents("tr").find(".risk_add, .risk_edit").toggle();
				$(".add-new-risk").attr("disabled", "disabled");
			});
			
			
			// Delete row on delete button click
			$(document).on("click", ".risk_delete", function(){
				$('[data-toggle="tooltip"]').tooltip("hide");
				$(this).parents("tr").remove();
				$(".add-new-risk").removeAttr("disabled");	
			});
			
			
			
			//SLA
			
			var sla_actions = '<a class="sla_add" title="Add" data-toggle="tooltip"><i class="fa fa-save"></i></a><a class="sla_edit" title="Edit" data-toggle="tooltip"><i class="fa fa-pencil"></i></a><a class="sla_delete" title="Delete" data-toggle="tooltip"><i class="fa fa-trash"></i></a>';
			// Append table with add row form on add new button click 

			$(".add-new-sla").click(function(){
				$(this).attr("disabled", "disabled");
				var index = $(".sla_table tbody tr:last-child").index();
				var sla_types_str = $("#sla_type_str").text();
				var typeArray = sla_types_str.split(',');
				var typeStr = ''
				for(var i = 0; i<typeArray.length;i++)
					{
							typeStr += '<option>'+typeArray[i]+'</option>' 
					}	
				var row = '<tr>' +
					'<td>'+
						'<select name="sla" class="form-control mb-3 mb-3 sla" required="" id="sla">'+
							'<option value="Select SLA" selected="">Select SLA</option>'+typeStr+'</select>'+
					'</td>'+
					'<td>'+
						'<select name="priority" class="form-control mb-3 mb-3 priority" required="" id="priority"><option value="Select Priority" selected="">Select Priority</option>'+
						'<option>P1</option>'+
						'<option>P2</option>'+						
						'<option>P3</option>'+						
						'<option>P4</option>'+						
						'<option>Normal</option>'+						
						'<option>Standard</option>'+						
						'<option>High</option>'+						
						'<option>Critical</option>'+						
						'<option>Other</option>'+						
						'</select>'+
					'</td>' +
					'<td><input type="text" class="form-control" name="response_time" id="response_time" placeholder="Response Time "></td>'+
					'<td><input type="text" class="form-control" name="resolution_time" id="resolution_time" placeholder="Resolution Time "></td>'+
					'<td><input type="text" class="form-control" name="sla_remarks" id="sla_remarks" placeholder="Remarks"></td>' +
					'<td>' + sla_actions + '</td>' +
				'</tr>';
				$(".sla_table").append(row);		
				$(".input-datepicker").datepicker({autoclose:!0,format:"yyyy-mm-dd"})
				$(".sla_table tbody tr").eq(index + 1).find(".sla_add, .sla_edit").toggle();
				$('[data-toggle="tooltip"]').tooltip();
			});
			
			$(document).on("click", ".sla_edit", function(){	
				var sla = $(this).parents('tr').find('td').eq(0).html();
				var sla_types_str = $("#sla_type_str").text();
				var typeArray = sla_types_str.split(',');
				var typeStr = ''
				for(var i = 0; i<typeArray.length;i++)
				{
						typeStr += '<option>'+typeArray[i]+'</option>' 
				}
				$(this).parents('tr').find('td').eq(0).html('<select name="sla" class="form-control mb-3 mb-3 sla" required="" id="sla">'+
							'<option value="Select SLA" selected="">Select SLA</option>'+typeStr+'</select>');
				$(".sla").val(sla); 
				
				var priority = $(this).parents('tr').find('td').eq(1).html(); 
				$(this).parents('tr').find('td').eq(1).html('<select name="priority" class="form-control mb-3 mb-3 priority" required="" id="priority"><option value="Select Priority" selected="">Select Priority</option>'+
						'<option>P1</option>'+
						'<option>P2</option>'+						
						'<option>P3</option>'+						
						'<option>P4</option>'+						
						'<option>Normal</option>'+						
						'<option>Standard</option>'+						
						'<option>High</option>'+						
						'<option>Critical</option>'+						
						'<option>Other</option>'+						
						'</select>');
				$(".priority").val(priority); 
				
				var responsetime = $(this).parents('tr').find('td').eq(2).html();  
				if(responsetime === 'Response Time'){
					$(this).parents('tr').find('td').eq(2).html('<input type="text" class="form-control " name="response_time" id="response_time" placeholder="' + responsetime + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(2).html('<input type="text" class="form-control " name="response_time" id="response_time" value="' + responsetime + '">');
				}
				
				var restime = $(this).parents('tr').find('td').eq(3).html();  
				if(restime === 'Resolution Time'){
					$(this).parents('tr').find('td').eq(3).html('<input type="text" class="form-control " name="resolution_time" id="resolution_time" placeholder="' + restime + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(3).html('<input type="text" class="form-control " name="resolution_time" id="resolution_time" value="' + restime + '">');
				}
				
				var sl_remarks = $(this).parents('tr').find('td').eq(4).html();  
				if(sl_remarks === 'Remarks'){
					$(this).parents('tr').find('td').eq(4).html('<input type="text" class="form-control " name="sla_remarks" id="sla_remarks" placeholder="' + sl_remarks + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(4).html('<input type="text" class="form-control " name="sla_remarks" id="sla_remarks" value="' + sl_remarks + '">');
				}
				
				$(this).parents("tr").find(".sla_add, .sla_edit").toggle();
				$(".add-new-sla").attr("disabled", "disabled");
			});
			// Delete row on delete button click
			$(document).on("click", ".sla_delete", function(){
				$('[data-toggle="tooltip"]').tooltip("hide");
				$(this).parents("tr").remove();
				$(".add-new-sla").removeAttr("disabled");	
			});
			
			// Automation
			var automation_actions = '<a class="automation_add" title="Add" data-toggle="tooltip"><i class="fa fa-save"></i></a><a class="automation_edit" title="Edit" data-toggle="tooltip"><i class="fa fa-pencil"></i></a><a class="automation_delete" title="Delete" data-toggle="tooltip"><i class="fa fa-trash"></i></a>';
			// Append table with add row form on add new button click 

			$(".add-new-automation").click(function(){
				$(this).attr("disabled", "disabled");
				var index = $(".automation_table tbody tr:last-child").index();
				var sc_str = $("#sc_str").text();
				var typeArray = sc_str.split(',');
				var typeStr = ''
				for(var i = 0; i<typeArray.length;i++)
					{
							typeStr += '<option>'+typeArray[i]+'</option>' 
					}
					
				var au_meth = $("#au_meth").text();
				var typeArrayau_meth = au_meth.split(',');
				var typeStrau_meth = ''
				for(var i = 0; i<typeArrayau_meth.length;i++)
					{
							typeStrau_meth += '<option>'+typeArrayau_meth[i]+'</option>' 
					}	
				var row = '<tr><td><input type="text" class="form-control" name="solution" id="solution" placeholder="Solution"></td>'+
					'<td>'+
						'<select name="solution_category" class="form-control mb-3 mb-3 solution_category" required="" id="solution_category">'+
							'<option value="Select Category" selected="">Select Category</option>'+typeStr+'</select>'+
					'</td>'+
					'<td>'+
						'<select name="solution_category" class="form-control mb-3 mb-3 solution_type" required="" id="solution_type">'+
							'<option value="Select Type" selected="">Select Type</option>'+typeStrau_meth+'</select>'+
					'</td>'+
					'<td>'+
						'<select name="au_status" class="form-control mb-3 mb-3 au_status" required="" id="au_status"><option value="Select Status" selected="">Select Status</option>'+
							'<option>Deployed</option>'+
							'<option>Pending</option>'+					
						'</select>'+
					'</td>' +
					'<td><input type="text" class="form-control input-datepicker" name="deploy_date" id="deploy_date" placeholder="Date of Deploy"></td>'+
					'<td>' + automation_actions + '</td>' +
				'</tr>';
			
				$(".automation_table").append(row);		
				
				$(".input-datepicker").datepicker({autoclose:!0,format:"yyyy-mm-dd"});
				$(".automation_table tbody tr").eq(index + 1).find(".automation_add, .automation_edit").toggle();
				$('[data-toggle="tooltip"]').tooltip();
			});
			
			$(document).on("click", ".automation_edit", function(){	
				var solution = $(this).parents('tr').find('td').eq(0).html();
				var sc_str = $("#sc_str").text();
				var typeArray = sc_str.split(',');
				var typeStr = ''
				for(var i = 0; i<typeArray.length;i++)
					{
							typeStr += '<option>'+typeArray[i]+'</option>' 
					}
					
				var au_meth = $("#au_meth").text();
				var typeArrayau_meth = au_meth.split(',');
				var typeStrau_meth = ''
				for(var i = 0; i<typeArrayau_meth.length;i++)
					{
							typeStrau_meth += '<option>'+typeArrayau_meth[i]+'</option>' 
					}	
				if(solution === 'NA'){
					$(this).parents('tr').find('td').eq(0).html('<input type="text" class="form-control " name="solution" id="solution" placeholder="' + solution + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(0).html('<input type="text" class="form-control " name="solution" id="solution" value="' + solution + '">');
				}
				

				
				var solution_category = $(this).parents('tr').find('td').eq(1).html(); 
				if(solution_category === 'NA'){ solution_category = 'Select Category';}
				$(this).parents('tr').find('td').eq(1).html('<select name="solution_category" class="form-control mb-3 mb-3 solution_category" required="" id="solution_category">'+
							'<option value="Select Category" selected="">Select Category</option>'+typeStr+'</select>');
				$(".solution_category").val(solution_category); 
				
				var solution_type = $(this).parents('tr').find('td').eq(2).html(); 
				if(solution_type === 'NA'){ solution_type = 'Select Type';}
				$(this).parents('tr').find('td').eq(2).html('<select name="solution_type" class="form-control mb-3 mb-3 solution_type" required="" id="solution_type">'+
							'<option value="Select Type" selected="">Select Type</option>'+typeStrau_meth+'</select>');
				$(".solution_type").val(solution_type);
				
				var solution_status = $(this).parents('tr').find('td').eq(3).html();
				if(solution_status === 'NA'){ solution_status = 'Select Status';}
				$(this).parents('tr').find('td').eq(3).html('<select name="au_status" class="form-control mb-3 mb-3 au_status" required="" id="au_status"><option value="Select Status" selected="">Select Status</option>'+
							'<option>Deployed</option>'+
							'<option>Pending</option>'+					
						'</select>');
				$(".au_status").val(solution_status);
				
				var deploydate = $(this).parents('tr').find('td').eq(4).html(); 
				if(deploydate === 'NA'){
					$(this).parents('tr').find('td').eq(4).html('<input type="text" class="form-control input-datepicker" name="deploy_date" id="deploy_date" placeholder="' + solution + '">');
				}
				else
				{
					$(this).parents('tr').find('td').eq(4).html('<input type="text" class="form-control input-datepicker" name="deploy_date" id="deploy_date" value="' + solution + '">');
				}
					
				$(".input-datepicker").datepicker({autoclose:!0,format:"yyyy-mm-dd"});
				$(this).parents("tr").find(".automation_add, .automation_edit").toggle();
				$(".add-new-automation").attr("disabled", "disabled");
			});
			// Delete row on delete button click
			$(document).on("click", ".automation_delete", function(){
				$('[data-toggle="tooltip"]').tooltip("hide");
				$(this).parents("tr").remove();
				$(".add-new-automation").removeAttr("disabled");	
			});
			
			
			//Submit Form
			$("#submit_btn").click(function(){			
				var acc_name = $("#id_acc_name").val();
				var acc_model = $("#id_acc_model").val();
				var acc_type = $("#id_acc_type").val();
				var acc_s_model = $("#id_acc_support_model").val();
				var acc_vertical = $("#id_acc_vertical").val();
				var acc_location = $("#id_acc_location").val();
				var acc_geo = $("#id_acc_geo").val();
				var p_tool = $("#p_tool").val();
				var patch_tool = $('#patch_tool').val();
				var patch_m_tool = $('#patch_m_tool').val();
				var conf_tool = $('#conf_tool').val();
				var assess_date = $('#assess_date').val();
				var assessor = $('#assessor').val();
				var assess_remarks = $('#assess_remarks').val();
			});
			
			
		});
		
		
$('#id_acc_name').blur(function(){
	var accname = $('#id_acc_name').val();
	$('#error_acc_name').html('');
	if(accname == null || accname =='')
	{
		$('#error_acc_name').html('Field is required');
	}	
});

$('#id_acc_model').blur(function(){
	var acc_model = $('#id_acc_model').val();
	$('#error_acc_model').html('');
	if(acc_model == null || acc_model =='-1')
	{
		$('#error_acc_model').html('Field is required');
	}	
});


$('#id_acc_type').blur(function(){
	var acc_type = $('#id_acc_type').val();
	$('#error_acc_type').html('');
	if(acc_type == null || acc_type =='-1')
	{
		$('#error_acc_type').html('Field is required');
	}	
});


$('#id_acc_support_model').blur(function(){
	var support_model = $('#id_acc_support_model').val();
	$('#error_support_model').html('');
	if(support_model == null || support_model =='-1')
	{
		$('#error_support_model').html('Field is required');
	}	
});


$('#p_tool').blur(function(){
	var p_tool = $('#p_tool').val();
	$('#error_p_tool').html('');
	if(p_tool == null || p_tool =='')
	{
		$('#error_p_tool').html('Field is required');
	}	
});

$('#patch_tool').blur(function(){
	var patch_tool = $('#patch_tool').val();
	$('#error_patch_tool').html('');
	if(patch_tool == null || patch_tool =='')
	{
		$('#error_patch_tool').html('Field is required');
	}	
});

$('#patch_m_tool').blur(function(){
	var patch_m_tool = $('#patch_m_tool').val();
	$('#error_patch_m_tool').html('');
	if(patch_m_tool == null || patch_m_tool =='')
	{
		$('#error_patch_m_tool').html('Field is required');
	}	
});

$('#conf_tool').blur(function(){
	var conf_tool = $('#conf_tool').val();
	$('#error_conf_tool').html('');
	if(conf_tool == null || conf_tool =='')
	{
		$('#error_conf_tool').html('Field is required');
	}	
});