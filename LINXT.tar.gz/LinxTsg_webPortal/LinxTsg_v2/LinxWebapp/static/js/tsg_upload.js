$(function(){			//tsgupload
			var loadForm = function () {
					var acc_name = $("#id_acc_name").val();
					if(acc_name == null || acc_name =='')
					{
						$("#id_acc_name").focus()
						$('#error_acc_name').html('Field is required');
					}
					else
					{
					var btn = $(this);
					$.ajax({
					  url: btn.attr("data-url"),
					  type: 'get',
					  dataType: 'json',
					  beforeSend: function () {
						$("#addmodal").modal("show");
					  },
					  success: function (data) {
						$("#addmodal .modal-content").html(data.html_form);
						var data_provider = $("#user_email").text();
						$("#addmodal .modal-content #id_data_provider").val('');
						$("#addmodal .modal-content #id_data_provider").val(data_provider);
						$("#addmodal .modal-content #id_acc_name").val(acc_name);
						$('#addmodal .modal-content input[type="file"]').change(function(e){
						var fileName = e.target.files[0].name;
						$("#addmodal .modal-content #id_title").val(fileName);
						
						});
						
					  }
					});
					}
				  };
				  

				var saveForm = function () {
								var form = $("#addmodal .form_upload_tsg")[0];		
								var btn = $(this);
								
								$.ajax({
									  url: btn.attr("data-url"),
									  data: new FormData(form),
									  type: 'POST',
									  dataType: 'json',
									  processData: false,
									  contentType: false,
									  success: function (data) {
									
										 if(data.form_is_valid)
										 {
											Messenger().post({message:data.message,type:"success"})
											$("#addmodal").modal("hide");
											$("#tsg_table").html("");
											$("#tsg_table").append(data.tsg_table);
											
											var e= $("#tsg_assess_table").DataTable({
												responsive:{details:!1},
											});
											$(document).on("sidebarChanged",function(){e.columns.adjust(),e.responsive.recalc(),e.responsive.rebuild()})
										 }
										 else{
											Messenger().post({message:data.message,type:"error"})
										 }

									  }
								});  
								return false;
							  };
			
			$(document).on("click", ".upload_file", loadForm)	
			$(document).on("click", ".form_tsg_upload", saveForm)	
}); 