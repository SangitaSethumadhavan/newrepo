$(function () { 
		datatable();
		});

	
function datatable(){
	
	var e= $("#datatable1").DataTable({
										responsive:{details:!1},
										"processing" : true,
										lengthMenu: [
											[ 15, 25, 50, -1 ],
											[ '15', '25', '50', 'Show all' ]
										],									
										"ajax" :"emr_info/getemrdata/",
										"columns" : [
										{"data" : "ref_id"},
										{"data" : "EMP_CODE"},
										{"data" : "EMP_NAME"},
										{"data" : "CAREER_BAND"},
										{"data" : "GROUP_CUSTOMER_NAME"},
										{"data" : "LOCATION"},
										]
									});
	
	$(document).on("sidebarChanged",function(){e.columns.adjust(),e.responsive.recalc(),e.responsive.rebuild()})
}