$(function () { 
		datatable();
	    Messenger.options={
						extraClasses:"messenger-fixed messenger-on-top  messenger-on-right",theme:"flat",messageDefaults:{
						showCloseButton:!0}
					}
	   var loadForm = function () {
			var btn = $(this);
			$.ajax({
			  url: btn.attr("data-url"),
			  type: 'get',
			  dataType: 'json',
			  beforeSend: function () {
				$("#addmodal").modal("show");
			  },
			  success: function (data) {
				$("#addmodal .modal-content").html(data.html_form);
			  }
			});
		  };

				
	    var saveForm = function () {
								var form = $(this);
								$.ajax({
									  url: form.attr("action"),
									  data: form.serialize(),
									  type: form.attr("method"),
									  dataType: 'json',
									  success: function (data) {
										 if(data.form_is_valid)
										 {
											Messenger().post({message:data.message,type:"success"})
											$("#addmodal").modal("hide");
										 }
										 else{
											Messenger().post({message:data.message,type:"error"})
										 }
										$('#datatable1').DataTable().destroy();
										datatable();
									  }
								}); 
								return false;
							  };
	$(".add_category").click(loadForm);
	$("#addmodal").on("submit", ".form_add_category", saveForm);
	
	$("#datatable1").on("click", ".js-update-category", loadForm);
	$("#addmodal").on("submit", ".js-category-update-form", saveForm);
  
	$("#datatable1").on("click", ".js-delete-category", loadForm);
	$("#addmodal").on("submit", ".js-category-delete-form", saveForm);

	});

	
function datatable(){

	var e= $("#datatable1").DataTable({
										responsive:{details:!1},
										"processing" : true,
										lengthMenu: [
											[ 5, 25, 50, -1 ],
											[ '5', '25', '50', 'Show all' ]
										],									
										"ajax" :"category_info/getcategorydata/",
										"columns" : [
										{"data" : "ref_id"},
										{"data" : "category"},
										{"data" : "added_on"},
										{"data" : "added_by"},
										{
											 data: null,
											 className: "center",render: function ( data, type, row ) {
											// Combine the first and last names into a single table field
											return '<button type="button" class="btn btn-icon waves-effect waves-light m-b-5 js-update-category" style=" background: none; color: #f9c851; " data-url="category_info/'+data.category_id+'/update/"><i class="fa fa-pencil"></i></button><button type="button" class="btn btn-icon waves-effect waves-light  m-b-5 js-delete-category" style=" background: none; color: red; " data-url="category_info/'+data.category_id+'/delete/"><i class="fa fa-trash"></i> </button>'
											} 
										},	
										]
									});
	
	$(document).on("sidebarChanged",function(){e.columns.adjust(),e.responsive.recalc(),e.responsive.rebuild()})
}