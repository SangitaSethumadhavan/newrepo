#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
	----------------------------------------
	LDAP Authentication
	----------------------------------------
        Created  		: 06-03-2019                
        Author   		: CIS,wipro.com     		
        Purpose  		: LDAP Authentication		
        Modified Date 	: 06-03-2019                
        Modified By 	: TSG - CIS		
	Need to Install ldap3 , traitlets
"""


import re
import ldap3
from ldap3.utils.conv import escape_filter_chars
from traitlets import HasTraits,Unicode, Int, Bool, List, Union
import sys


class Valid_password_Exception(Exception):
	def __init__(self, error_message): 
		self.eelrror_message = error_message 

class LDAPAuthenticator(HasTraits):

	username = None
	password = None

	server_address = Unicode(
        config=True,
        help="""
        Address of the LDAP server to contact.
        Could be an IP address or hostname.
        """
    )
	
	server_port = Int(
		config=True,
        help="""
        Port on which to contact the LDAP server.
        Defaults to `636` if `use_ssl` is set, `389` otherwise.
        """
    )
	
	""" _server_port_default return the port for LDAP """
	def _server_port_default(self):
		if self.use_ssl:
			return 636  # default SSL port for LDAP
		else:
			return 389  # default plaintext port for LDAP
	
	use_ssl = Bool(
        False,
        config=True,
        help="""
        Use SSL to communicate with the LDAP server.
        Deprecated in version 3 of LDAP. Your LDAP server must be configured to support this, however.
        """
    )
	
	search_filter = Unicode(
        config=True,
        help="LDAP3 Search Filter whose results are allowed access"
    )
	
	user_attribute = Unicode(
        config=True,
        default=None,
        allow_none=True,
        help="""
        Attribute containing user's name, if `lookup_dn` is set to True.
        See `user_search_base` for info on how this attribute is used.
        For most LDAP servers, this is uid.  For Active Directory, it is
        samAccountName.
        """
    )
	
	attributes = List(
        config=True,
        help="List of attributes to be searched"
    )
	# Protect against invalid usernames as well as LDAP injection attacks
	def valid_username_check(self,username):
		if '@wipro.com' in username.lower():
			
			return username
		else:
			user_name = username + "@wipro.com"
			return user_name

	def valid_password_check(self,password):
		# No empty passwords!
		if password is None or password.strip() == '':
			#raise Valid_password_Exception("The Password is Blank")
			return None
		else:
			return password

	def get_connection(self, userdn, password):
		try:
			server = ldap3.Server(
				self.server_address,
				port=self.server_port,
				use_ssl=self.use_ssl
			)
			auto_bind = (
				self.use_ssl
				and ldap3.AUTO_BIND_TLS_BEFORE_BIND
				or ldap3.AUTO_BIND_NO_TLS
			)
			# connection starts
			conn = ldap3.Connection(
				server,
				user=userdn,
				password=password,
				auto_bind=auto_bind,
			)
			return conn
		except ldap3.core.exceptions.LDAPSocketOpenError as socker_error:
			return 0	
	
	def authenticate(self,data):
		result_set_dict = dict()
		result_set_dict["error_flag"] = False
		username = data['username']
		password = data['password']
		conn = self.get_connection(username, password)
		if conn != 0:
			is_bound = conn.bind()
			if not is_bound:
				msg = "Invalid password for user '"+username+"'"
				error_message = msg
				result_set_dict["error_message"] = error_message
				result_set_dict["error_flag"] = True
			else:
				if self.search_filter:
					search_filter = self.search_filter.format(
										userattr=self.user_attribute,
										username=username,
									)
									
					conn.search(
								self.user_search_base,
								search_scope=ldap3.SUBTREE, 
								search_filter=search_filter,
								attributes=self.attributes)
					n_users = len(conn.response)
					
					if n_users == 0:
						msg = "User with '"+username+"' not found in directory"
						result_set_dict["error_flag"] = True
						error_message = msg
						result_set_dict["error_message"] = error_message
					if n_users > 1:
						msg = (
							"Duplicate users found! "
							""+str(n_users)+" users found with '"+username+"'"
						)
						result_set_dict["error_flag"] = True
						error_message = msg
						result_set_dict["error_message"] = error_message
					if not result_set_dict["error_flag"]:
						result_obj = conn.response
						for result in result_obj:
							result_set_dict["adid"] = result["attributes"]["cn"]
							result_set_dict["givenName"] = result["attributes"]["givenName"]
							result_set_dict["displayName"] = result["attributes"]["displayName"]
							result_set_dict["mail"] = result["attributes"]["mail"]
		else:
			is_bound = False 
			error_message = "Failed to connect to LDAP server with search user '"+username+"'"
			result_set_dict["error_message"] = error_message
			result_set_dict["error_flag"] = True
		return result_set_dict

	def _ldap_server_check(self,data):
		sercer_list = ["ldap://10.200.50.100","ldap://10.200.51.100","ldap://10.200.52.100"]
		dns_list = []
		wrking_server = 'ldap://10.200.50.100'
		for server_ip in sercer_list:
			conn = self.get_connection(data['username'], data['password'])
			if conn != 0:
				wrking_server = serevr_ip
				break;
		return wrking_server
	
# if __name__ == "__main__":
	# print (":----Here Starts the Main Function-------")
	
def LDAP_authentication(username,password):
	try:
		result_set_dict = dict()
		common_flag = True
		ldap_obj = LDAPAuthenticator()
		if username is None or username.strip() == '':
			result_set_dict["error_flag"] = True
			common_flag = False
			result_set_dict["error_message"] = "The Username must contain ADID or ADID@wipro.com"
		else:
			ldap_obj.username = ldap_obj.valid_username_check(username)
			result_set_dict["error_flag"] = False
		
		if common_flag:
			ldap_obj.password = ldap_obj.valid_password_check(password)
			if ldap_obj.password is None:
				result_set_dict["error_flag"] = True
				common_flag = False
				result_set_dict["error_message"] = "The Password must contain atleast one character!!!!!"
			else:
				result_set_dict["error_flag"] = False
		
		if common_flag :
			data = dict(username=ldap_obj.username,password=ldap_obj.password)
			ldap_obj.server_address = ldap_obj._ldap_server_check(data)   
			ldap_obj.server_port = ldap_obj._server_port_default()
			ldap_obj.user_search_base = 'OU=WIPRO,DC=wipro,DC=com'	
			ldap_obj.user_attribute = 'CN'
			ldap_obj.attributes = ['CN','mail','givenName','displayName'] 	
			ldap_obj.search_filter = '(samaccountname='+str(username)+')'
			rs = ldap_obj.authenticate(data) 
			result_set_dict = rs
		return result_set_dict
	except Exception as e:
		result_set_dict["error_message"] = "Your Account is blocked! "+str(e)
		result_set_dict["error_flag"] = True
		return result_set_dict

# call This method in your application
# pass username and password	
#user_name_test = ""
#user_pass_test = ""

#result_set_dict = LDAP_authentication(user_name_test,user_pass_test)
