# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.conf import settings
import hashlib
import datetime
import os
from functools import partial
User = settings.AUTH_USER_MODEL


def _update_filename(instance, filename, path):
	path 			= path
	_datetime 		= datetime.datetime.now()
	datetime_str 	= _datetime.strftime("%Y-%m-%d-%H-%M-%S")
	file 			= filename.split('.')
	modified_name	= file[0]+'_'+ str(datetime_str)+'.'+file[1]
	return os.path.join(path, modified_name)

def upload_to(path):
	return partial(_update_filename, path=path)

def _update_upload_filename(instance, filename, path,second_path):
	path 			= path+instance.acc_name+second_path
	_datetime 		= datetime.datetime.now()
	datetime_str 	= _datetime.strftime("%Y-%m-%d-%H-%M-%S")
	file 			= filename.split('.')
	modified_name	= file[0]+'_'+ str(datetime_str)+'.'+file[1]
	return os.path.join(path, modified_name)
	
def upload_file_data(path,second_path):
	return partial(_update_upload_filename, path=path,second_path=second_path)
	
class LoggedInUser(models.Model):
	'''
		logged user session management for one session for one user
	'''
	user 			= models.OneToOneField(User,related_name="logged_in_user",on_delete=models.CASCADE)
	session_key 	= models.CharField(max_length=32,blank=True,null=True)
	
	def __str__(self):
		return self.user.username
	
	class Meta:
		db_table = "LT_LoggedInUser"
		
class AccessRequest(models.Model):
	'''
		contains users access requests to LinuxTsg Web portal
	'''
	user_id 			= models.AutoField(primary_key=True)
	user_email 		= models.CharField(max_length = 200)
	user_adid 		= models.CharField(max_length = 60)
	user_addom 		= models.CharField(max_length = 60)
	user_type 		= models.CharField(max_length = 100)
	request_status 	= models.TextField(blank=True)
	requested_date 	= models.DateField(auto_now=True)	
	approved_by 	=  models.TextField(blank=True)
	approved_date 	=  models.DateField(auto_now=True,auto_now_add=False)	
	
	class Meta:
		db_table = "LT_AccessRequest"
	
	def access_request_to_json(self,obj_count):
		'''
			return json data of requests from model to view
		'''
		return {'tb_id':self.user_id,'ref_id':obj_count,'user_email':self.user_email,'user_adid':self.user_adid,'user_type':self.user_type,'requested_date':self.requested_date,'approved_by':self.approved_by,'request_status':self.request_status}
		
		
class AccountData(models.Model):
	'''
		Store all data about Accounts
	'''
	acc_id 				= models.AutoField(primary_key=True)
	acc_name 			= models.CharField(blank=False,max_length = 100)
	acc_model 			= models.CharField(blank=True,max_length = 100)
	acc_type 			= models.CharField(blank=True,max_length = 100)
	acc_support_model 	= models.CharField(blank=True,max_length = 100)
	acc_vertical 			= models.CharField(blank=True,max_length = 100)
	acc_location 			= models.CharField(blank=True,max_length = 100)
	acc_geo 				= models.CharField(blank=True,max_length = 100)
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 			= models.DateField(null=True, blank=True)
	modified_by 			= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_AccountData"

class ToolInfo(models.Model):
	'''
		Store all Tool Informations
	'''
	tool_id 				= models.AutoField(primary_key=True)
	acc_name 			= models.CharField(blank=False,max_length = 100)	
	provisioning_tool		= models.CharField(blank=False,max_length = 100)	
	patch_m_tool		= models.CharField(blank=False,max_length = 100)	
	patch_management	= models.CharField(blank=False,max_length = 100)	
	conf_tool	= models.CharField(blank=False,max_length = 100)	
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 		= models.DateField(null=True, blank=True)
	modified_by 		= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_ToolInfo"	

class TsgAssessment(models.Model):
	'''
		Store all TSG Assessment Informations
	'''
	t_id 				= models.AutoField(primary_key=True)
	acc_name 			= models.CharField(blank=False,max_length = 100)	
	assess_date			= models.DateField()
	assessor				= models.CharField(blank=False,max_length = 100)	
	remarks				= models.CharField(blank=False,max_length = 100)	
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 		= models.DateField(null=True, blank=True)
	modified_by 		= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_TsgAssessment"	

class ServerData(models.Model):
	'''
		Store all data about Server
	'''
	s_id 				= models.AutoField(primary_key=True)
	acc_name    			= models.CharField(blank=False,max_length = 100)
	os 					= models.CharField(blank=False,max_length = 100)
	os_type    			= models.CharField(blank=False,max_length = 100)
	version_name 		= models.CharField(blank=False,max_length = 100) 
	server_count 			= models.PositiveIntegerField(default=0)
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 			= models.DateField(null=True, blank=True)
	modified_by 			= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_ServerData"

class OSData(models.Model):
	'''
		Store all Os Related Data
	'''
	os_id 				= models.AutoField(primary_key=True)
	os_type 				= models.CharField(blank=True,max_length = 100)
	os 					= models.CharField(blank=False,max_length = 100)
	architecture 			= models.CharField(blank=True,max_length = 100)
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 			= models.DateField(null=True, blank=True)
	modified_by 			= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_OSData"
		
	def os_data_json(self,obj_count):
		'''
			return json data of requests from model to view
		'''
		return {'ref_id':obj_count,'os_id':self.os_id,'os_type':self.os_type,'os':self.os,'architecture':self.architecture,'added_on':self.added_on,'added_by':self.added_by}

class OSVarient(models.Model):
	os 					= models.CharField(blank=False,max_length = 100)
	os_varient 			= models.CharField(blank=False,max_length = 100)
	varient_version 		= models.FloatField(default=0,blank=False)
	version_name 		= models.CharField(blank=False,max_length = 100)	
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 		= models.DateField(null=True, blank=True)
	modified_by 		= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_OSVarient" 
	
	def os_varient_data_json(self,obj_count):
		'''
			return json data of requests from model to view
		'''
		return {'ref_id':obj_count,'os_id':self.id,'os_varient':self.os_varient,'os':self.os,'varient_version':self.varient_version,'version_name':self.version_name,'added_on':self.added_on,'added_by':self.added_by}
	
			
#category
class CategoryData(models.Model):
	'''
		Store all Category Related Data
	'''
	category_id 			= models.AutoField(primary_key=True)
	category 			= models.CharField(blank=False,max_length = 100)
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 			= models.DateField(null=True, blank=True)
	modified_by 		= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_CategoryData"
		
	def category_data_json(self,obj_count):
		'''
			return json data of requests from model to view
		'''
		return {'ref_id':obj_count,'category_id':self.category_id,'category':self.category,'added_on':self.added_on,'added_by':self.added_by}
		
		
		
		
#sla

class SLAData(models.Model):
	'''
		Store all SLA Related Data
	'''
	sla_id 				= models.AutoField(primary_key=True)
	sla		 			= models.CharField(blank=False,max_length = 100)
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 			= models.DateField(null=True, blank=True)
	modified_by 		= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_SLAData"
		
	def SLA_data_json(self,obj_count):
		'''
			return json data of requests from model to view
		'''
		return {'ref_id':obj_count,'sla_id':self.sla_id,'sla':self.sla,'added_on':self.added_on,'added_by':self.added_by}
		
#automation method
class AutomationMethodData(models.Model):
	'''
		Store all automation method Related Data
	'''
	automation_id 		= models.AutoField(primary_key=True)
	method 				= models.CharField(blank=False,max_length = 100)
	added_on 			= models.DateField()
	added_by 			= models.CharField(blank=True,max_length = 100)
	modified_on 		= models.DateField(null=True, blank=True)
	modified_by 		= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_AutomationMethodData"
		
	def automationmethoddata_data_json(self,obj_count):
		'''
			return json data of requests from model to view
		'''
		return {'ref_id':obj_count,'automation_id':self.automation_id,'method':self.method,'added_on':self.added_on,'added_by':self.added_by}
		
		
class RiskRegister(models.Model):
	'''
		Store All Risks related to Accounts
	'''
	
	risk_id					= models.AutoField(primary_key=True)
	acc_name    			= models.CharField(blank=False,max_length = 100)
	risk_info				= models.CharField(blank=False,max_length = 200) # risk identified
	identified_date			= models.DateField()
	closure_date				= models.DateField()
	status    				= models.CharField(blank=False,max_length = 100)
	remarks    				= models.CharField(blank=False,max_length = 300)
	added_on 				= models.DateField()
	added_by 				= models.CharField(blank=True,max_length = 100)
	modified_on 			= models.DateField(null=True, blank=True)
	modified_by 			= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_RiskRegister"
		
		
class SLADataInfo(models.Model):
	'''
		Store All SLA data related to Accounts
	'''
	sla_id 					= models.AutoField(primary_key=True)
	acc_name    			= models.CharField(blank=False,max_length = 100)
	sla						= models.CharField(blank=False,max_length = 100)
	priority					= models.CharField(blank=False,max_length = 100)
	response_time			= models.CharField(blank=False,max_length = 100)
	resolution_time			= models.CharField(blank=False,max_length = 100)
	remarks    				= models.CharField(blank=False,max_length = 300)
	added_on 				= models.DateField()
	added_by 				= models.CharField(blank=True,max_length = 100)
	modified_on 			= models.DateField(null=True, blank=True)
	modified_by 			= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_SLADataInfo"
		
		
class AutomationInfo(models.Model):
	'''
		Store All Automation data related to Accounts
	'''
	au_id 					= models.AutoField(primary_key=True)
	acc_name    			= models.CharField(blank=False,max_length = 100)
	solution					= models.CharField(blank=False,max_length = 100)
	s_category				= models.CharField(blank=False,max_length = 100)
	s_type					= models.CharField(blank=False,max_length = 100)
	status					= models.CharField(blank=False,max_length = 100)
	date_of_deploy			= models.DateField()
	added_on 				= models.DateField()
	added_by 				= models.CharField(blank=True,max_length = 100)
	modified_on 				= models.DateField(null=True, blank=True)
	modified_by 				= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table = "LT_AutomationInfo"
		
class EMR(models.Model):
	'''
		Store all employee data related to UNIX 
	'''
	index 							= models.AutoField(primary_key=True)
	EMP_CODE 						= models.CharField(blank=True,max_length = 200)
	EMP_NAME						= models.CharField(blank=True,max_length = 200)
	FRESHER_INDEX					= models.CharField(blank=True,max_length = 200)
	ROOKIE_STATUS					= models.CharField(blank=True,max_length = 200)
	HOME_COMPANY_CODE			= models.CharField(blank=True,max_length = 200)
	DERIVED_EMP_COUNTRY			= models.CharField(blank=True,max_length = 200)
	COSTCTR						= models.CharField(blank=True,max_length = 200)
	CAREER_BAND  					= models.CharField(blank=True,max_length = 200)
	EMPLOYEE_EMAIL_ID				= models.CharField(blank=True,max_length = 200)
	LOCATION						= models.CharField(blank=True,max_length = 200)
	BENCH_STATUS					= models.CharField(blank=True,max_length = 200)
	SELECTED_ALLOCATED_ACCOUNT	= models.CharField(blank=True,max_length = 200)
	REMARKS						= models.CharField(blank=True,max_length = 200)
	AREA							= models.CharField(blank=True,max_length = 200)
	SAP_BU_DESC					= models.CharField(blank=True,max_length = 200)
	VERTICAL						= models.CharField(blank=True,max_length = 200)
	GROUP_CUSTOMER_NAME			= models.CharField(blank=True,max_length = 200)
	PROJECT_CODE					= models.CharField(blank=True,max_length = 200)
	PROJ_TENURE					= models.CharField(blank=True,max_length = 200)
	CUST_TENURE					= models.CharField(blank=True,max_length = 200)
	PRACTICE						= models.CharField(blank=True,max_length = 200)
	PRAC_CC_DESC					= models.CharField(blank=True,max_length = 200)
	DATE_OF_JOINING				= models.DateField()
	EXPERIENCE						= models.CharField(blank=True,max_length = 200)
	PRIMARY_SUPERVISOR			= models.CharField(blank=True,max_length = 200)
	PROJECT_SUPERVISOR_MAIL_ID	= models.CharField(blank=True,max_length = 200)
	FLEXPROJ						= models.CharField(blank=True,max_length = 200)
	Sum_of_Billable					= models.CharField(blank=True,max_length = 200)
	Sum_of_Non_Billable				= models.CharField(blank=True,max_length = 200)
	Sum_of_Support					= models.CharField(blank=True,max_length = 200)
	Sum_of_Free						= models.CharField(blank=True,max_length = 200)
	Sum_of_TOTAL_DAYS				= models.CharField(blank=True,max_length = 200)
	Status							= models.CharField(blank=True,max_length = 200)
	NB_Ageing						= models.CharField(blank=True,max_length = 200)
	NB_Age_Category					= models.CharField(blank=True,max_length = 200)
	RD_Date							= models.DateField(null=True, blank=True)
	RAMP_DOWN					= models.CharField(blank=True,max_length = 200)
	RD_Account						= models.CharField(blank=True,max_length = 200)
	RD_Ageing						= models.DateField(null=True, blank=True)
	RD_VERTICAL					= models.CharField(blank=True,max_length = 200)
	INVESTED_TO					= models.CharField(blank=True,max_length = 200)
	LEAVE_STAT						= models.CharField(blank=True,max_length = 200)
	DERIVED_SUITE_ID				= models.CharField(blank=True,max_length = 200)
	DERIVED_SUITE_NAME			= models.CharField(blank=True,max_length = 200)
	TOWER							= models.CharField(blank=True,max_length = 200)
	TOWER_1						= models.CharField(blank=True,max_length = 200)
	LEVEL							= models.CharField(blank=True,max_length = 200)
	CERTIFITED_SKILL				= models.CharField(blank=True,max_length = 300)
	UNASSESSED_SKILL				= models.CharField(blank=True,max_length = 300)
	TRAINING_SKILLS				= models.CharField(blank=True,max_length = 300)
	PROJECT_ACQUIRED_SKILL		= models.CharField(blank=True,max_length = 300)
	PROJ_TYPE						= models.CharField(blank=True,max_length = 200)
	ONS_OFF_FLAG					= models.CharField(blank=True,max_length = 200)
	RTR_STATUS					= models.CharField(blank=True,max_length = 200)
	ESSENTIAL_SKILL				= models.CharField(blank=True,max_length = 200)
	INDENT_ROLE_ID				= models.CharField(blank=True,max_length = 200)
	INDENT_ROLE_DESC				= models.CharField(blank=True,max_length = 300)
	DU_PRACTICE					= models.CharField(blank=True,max_length = 200)
	COMPANY_IDENTIFICATION_FG	= models.CharField(blank=True,max_length = 200)
	MODEL							= models.CharField(blank=True,max_length = 200)
	WIPRO_EXP						= models.CharField(blank=True,max_length = 200)
	added_on 						= models.DateField()
	added_by 						= models.CharField(blank=True,max_length = 100)
	
	class Meta:
		db_table 		= "LT_EMR"
		
	def EMR_data_json(self,obj_count):
		'''
			return json data of requests from model to view
		'''
		return {'ref_id':obj_count,'index':self.index,'EMP_CODE':self.EMP_CODE,'EMP_NAME':self.EMP_NAME,'CAREER_BAND':self.CAREER_BAND,'GROUP_CUSTOMER_NAME':self.GROUP_CUSTOMER_NAME,'LOCATION':self.LOCATION}
															
class TsgAssessUpload(models.Model):
	'''
		Uploaded details of TSG Assessment
	'''
	acc_name	 	= models.CharField(max_length=200)
	title = models.CharField(max_length=200)
	data_provider = models.CharField(max_length=200)
	uploaded_date = models.DateTimeField(auto_now=True)
	uploaded_file = models.FileField(upload_to=upload_file_data('Accounts/','/tsaAssess/'))
	
	class Meta:
		db_table 		= "LT_TsgAssessUpload"
		get_latest_by  	= 'uploaded_date'	

class AccountDocumentUpload(models.Model):
	'''
		Uploaded details of Account Documents
	'''
	acc_name	 	= models.CharField(max_length=200)
	title = models.CharField(max_length=200)
	data_provider = models.CharField(max_length=200)
	uploaded_date = models.DateTimeField(auto_now=True)
	uploaded_file = models.FileField(upload_to=upload_file_data('Accounts/','/documents/'))
	
	class Meta:
		db_table 		= "LT_AccountDocumentUpload"
		get_latest_by  	= 'uploaded_date'	

class EmrUpload(models.Model):
	title = models.CharField(max_length=200)
	data_provider = models.CharField(max_length=200)
	uploaded_date = models.DateTimeField(auto_now=True)
	uploaded_file = models.FileField(upload_to='EMR/')
	
	class Meta:
		db_table = "LT_EmrUpload"
		get_latest_by = 'uploaded_date'
	