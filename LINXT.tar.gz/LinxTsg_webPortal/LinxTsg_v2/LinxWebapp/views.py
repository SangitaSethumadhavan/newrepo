# -*- coding: utf-8 -*-
"""
Django views for LinxTsg_v2 project.

"""
from __future__ import unicode_literals
from django.shortcuts import render,get_object_or_404,\
							render_to_response,redirect
from django.http import *
import logging
from .forms import *
from django.template import RequestContext,exceptions
from django.template.loader import render_to_string
from LinxTsg_v2.logger import log,linxt_log,auth_log
from .backend.authentication import auth
from .backend.linux_onboard import acc_obj
from .backend.linux_os import s_obj
from .backend.emr_operations import e_obj
from django.contrib.auth import logout
import xlwt
import pandas as pd




# Here Coding Starts

def linxtsg_login_view(request):
	'''
		Login for access granted users
	'''
	data = dict()
	template_name = 'authentication/forms/login_form.html'
	if request.user is None or request.user.is_anonymous:
		if request.method == 'POST':
			form = Login_form(request.POST)
			if form.is_valid():
				info = auth.login_auth(form,request)
				if info['is_authenticated']:
					return redirect('Linux_dashboard') 
				else:
					data['message'] = info['message']
					auth_log.error(data['message'])
			else:
				data['message'] = 'Invalid form'
				auth_log.error("invalid form")
		else:
			form = Login_form()
		#User.objects.create_user('user@wipro.com', 'user@wipro.com', "")
		#User.objects.create_user('admin@wipro.com', 'admin@wipro.com', "")
		context = {'form': form}
		data['html_form'] = render_to_string(template_name, context, request=request)
		return render(request, 'authentication/lnxtsg_auth.html',data)
	else: 
		return redirect('Linux_dashboard') 

		
def linxtsg_access_request_view(request): 
	'''
		Request for LinxTsg access 
	'''
	data = dict()
	
	try:
		template_name = 'authentication/forms/access_request_form.html'
		data['is_msg'] = False
		if request.method == 'POST':
			'''
				Getting Access Request form data
			'''
			form = Access_Request_Form(request.POST)
			if form.is_valid():
				info = auth.accessrequestupdate(form)
				data['message'] = info['msg']
				data['is_msg'] = True
				form = Access_Request_Form()
				auth_log.info(data['message'])
			else:
				data['is_msg'] = True
				data['message'] = "Form Data not valid"
				auth_log.error(data['message'])
		else:
			form = Access_Request_Form()
	except Exception as e:
		'''
			Updating Log with the exception
		'''
		data['is_msg'] = True
		data['message'] = str(e)
		auth_log.error(str(e))
		form = Access_Request_Form()
	context = {'form': form}
	data['html_form'] = render_to_string(template_name, context, request=request)
	return render(request, 'authentication/lnxtsg_request_acess.html',data)

def access_request_approval_json(request):
	mod = 'All'
	if mod == "All":
		upoad_obj = AccessRequest.objects.all().order_by('-user_id').exclude(user_email__in=['admin@wipro.com','user@wipro.com'])
		data = []
		obj_count = 1
		for obj in upoad_obj:
			data.append(obj.access_request_to_json(obj_count))
			obj_count += 1
		response = {'data':data}
	return JsonResponse(response)	
	
def update_access_request(request, pk):
	ap = get_object_or_404(AccessRequest, pk=pk)
	if request.method == 'POST':
		form = ApprovalForm(request.POST, instance=ap)
	else:
		form = ApprovalForm(instance=ap)
	return auth.approve_access_form(request, form, 'authentication/forms/partial_access_update.html',ap.user_id)

def delete_user_request(request, pk):
	ur = get_object_or_404(AccessRequest, pk=pk)
	data = dict()
	if request.method == 'POST':
		ur.delete()
		data['message'] = 'User Deleted'
		data['form_is_valid'] = True  # This is just to play along with the existing code
	else:
		context = {'ur_obj': ur}
		data['html_form'] = render_to_string('authentication/forms/partial_access_delete.html',
            context,
            request=request,
        )
	return JsonResponse(data)
	
def approve_user_request(request, pk):
	ap = get_object_or_404(AccessRequest, pk=pk)
	if request.method == 'POST':
		form = ApprovalForm(request.POST, instance=ap)
	else:
		form = ApprovalForm(instance=ap)
	return auth.approve_access_form(request, form, 'authentication/forms/partial_access_approve.html',ap.user_id)
	
def linuxdashboard(request):
	data = dict()
	data['menu'] = {
					'area':'false',
					'onboard':'',
					'acc':'',
					'dash':'active',
					'os':'',
					'ov':'',
					'ac':'',
					'sla':'',
					'am':'',
					'du':'',
					'emp':'','editacc':'','areas':'false'}
	return render(request, 'linux_dashboard/linux_dash.html',data)

def access_approval(request):
	data = dict()
	data['menu'] = {
					'area':'false',
					'onboard':'',
					'acc':'',
					'dash':'',
					'os':'',
					'ov':'',
					'ac':'',
					'sla':'',
					'am':'',
					'ua':'active',
					'emp':'','editacc':'','areas':'false'}
	return render(request, 'authentication/request_approval.html',data)
	
def linuxaccountinformation(request):
	data = dict()
	data['menu'] = {'area':'true','onboard':'active','acc':'active','dash':'','os':'','ov':'','ac':'','sla':'','am':'','du':'','emp':'','editacc':'','areas':'false'}
	data["os_type"] = s_obj.get_os_types()
	data["sla_type"] = s_obj.get_sla_types()
	data["sc"] = s_obj.get_solution_category()
	data['au_meth'] = s_obj.get_automation_method()
	return render(request, 'onboard/account_info.html',data)

def change_account_information(request):
	data = dict()
	data['menu'] = {'area':'false','onboard':'','acc':'','dash':'','os':'','ov':'','ac':'','sla':'','am':'','du':'','emp':'','editacc':'active','areas':'true'}
	data["os_type"] = s_obj.get_os_types()
	data["sla_type"] = s_obj.get_sla_types()
	data["sc"] = s_obj.get_solution_category()
	data['au_meth'] = s_obj.get_automation_method()
	data['acc_form'] = AccountChoiceForm()
	return render(request, 'onboard/edit_account_info.html',data)
	
def get_os_flavours(request):
	data = dict()
	os_type = request.POST.get('os_type')
	data['flavour_list'] = render_to_string("onboard/choices/partial_os_flavour_list.html",{'flavours':s_obj.get_os_flavour(os_type)}, request=request)
	return JsonResponse(data) 
	
def get_os_versions(request):
	data = dict()
	os = request.POST.get('os')
	data['version_list'] = render_to_string("onboard/choices/partial_os_version_list.html",{'versions':s_obj.get_os_version(os)}, request=request)
	return JsonResponse(data) 

def save_server_informations(request):
	data = dict()
	data['message'] = s_obj.save_server_info(request)
	return JsonResponse(data)
	
def save_risk_informations(request):
	data = dict()
	data['message'] = s_obj.save_risk_info(request)
	return JsonResponse(data)
	
def save_sla_informations(request):
	data = dict()
	data['message'] = s_obj.save_sla_info(request)
	return JsonResponse(data)
	
def save_automation_informations(request):
	data = dict()
	data['message'] = s_obj.save_automation_info(request)
	return JsonResponse(data)
def save_account_informations(request):
	data = dict()
	data = s_obj.save_account_info(request)
	return JsonResponse(data)
	
def upload_tsgassess_file(request):
	data = {}
	if request.method == 'POST':
		form = TsgAssessUploadForm(request.POST, request.FILES)
	else:
		form = TsgAssessUploadForm()
	return s_obj.save_upload_tsgassess_form(request, form, 'onboard/forms/tsg_upload_form.html')

def upload_document_file(request):
	data = {}
	if request.method == 'POST':
		form = DocumentUploadForm(request.POST, request.FILES)
	else:
		form = DocumentUploadForm()
	return s_obj.save_upload_document_form(request, form, 'onboard/forms/acc_document_upload_form.html')
	
def os_info(request):
	'''
		Add OS informations and view OS informations
	'''
	data = dict()
	data['menu'] = {'area':'true','onboard':'active','acc':'','dash':'','os':'active','ov':'','ac':'','sla':'','am':'','du':'','emp':'','editacc':'','areas':'false'}
	return render(request, 'onboard/os_info.html',data)
	
	
def add_os(request):
	data = {}
	if request.method == 'POST':
		form = OS_form(request.POST, request.FILES)
	else:
		form = OS_form()
	return s_obj.save_os_form(request, form, 'onboard/forms/add_os.html',-1)

	
def update_os(request, pk):
	os = get_object_or_404(OSData, pk=pk)
	if request.method == 'POST':
		form = OS_form(request.POST, instance=os)
	else:
		form = OS_form(instance=os)
	return s_obj.save_os_form(request, form, 'onboard/forms/partial_os_update.html',os.os_id)
	
	
def delete_os(request, pk):
	os = get_object_or_404(OSData, pk=pk)
	data = dict()
	if request.method == 'POST':
		os.delete()
		data['message'] = 'OS Deleted.'
		data['form_is_valid'] = True  # This is just to play along with the existing code
	else:
		context = {'os_obj': os}
		data['html_form'] = render_to_string('onboard/forms/partial_os_delete.html',
            context,
            request=request,
        )
	return JsonResponse(data)

	
def onboard_os_data_json(request):
	mod = 'All'
	if mod == "All":
		upoad_obj = OSData.objects.all().order_by('-os_id')
		data = []
		obj_count = 1
		for obj in upoad_obj:
			data.append(obj.os_data_json(obj_count))
			obj_count += 1
		response = {'data':data}
	return JsonResponse(response)	

	
def os_varient_info(request):
	'''
		Add OS informations and view OS informations
	'''
	data = dict()
	data['menu'] = {'area':'true','onboard':'active','acc':'','dash':'','os':'','ov':'active','ac':'','sla':'','am':'','du':'','emp':'','editacc':'','areas':'false'}

	return render(request, 'onboard/os_varient_info.html',data)
	
	
def add_os_varient(request):
	
	data = {}
	if request.method == 'POST':
		form = OS_Varient_form(request.POST, request.FILES)
	else:
		form = OS_Varient_form()
	return s_obj.save_os_varient_form(request, form, 'onboard/forms/add_os_varient.html',-1)

	
def update_os_varient(request, pk):
	os = get_object_or_404(OSVarient, pk=pk)
	if request.method == 'POST':
		form = OS_Varient_form(request.POST, instance=os)
	else:
		form = OS_Varient_form(instance=os)
	return s_obj.save_os_varient_form(request, form, 'onboard/forms/partial_os_varient_update.html',os.id)
	
	
def delete_os_varient(request, pk): 
	os = get_object_or_404(OSVarient, pk=pk)
	data = dict()
	if request.method == 'POST':
		os.delete()
		data['message'] = 'OS Varient Deleted.'
		data['form_is_valid'] = True  # This is just to play along with the existing code
	else:
		context = {'os_varient_obj': os}
		data['html_form'] = render_to_string('onboard/forms/partial_os_varient_delete.html',
            context,
            request=request,
        )
	return JsonResponse(data)

	
def onboard_os_varient_data_json(request):
	mod = 'All'
	if mod == "All":
		upoad_obj = OSVarient.objects.all().order_by('-id')
		data = []
		obj_count = 1
		for obj in upoad_obj:
			data.append(obj.os_varient_data_json(obj_count))
			obj_count += 1
		response = {'data':data}
	return JsonResponse(response)	
	

#category
def category_info(request):
	'''
		Add Category informations and view Category informations
	'''
	data = dict()
	data['menu'] = {'area':'true','onboard':'active','acc':'','dash':'','os':'','ac':'active','am':'','sla':'','ta':'','du':'','emp':'','editacc':'','areas':'false'}
	return render(request, 'onboard/category_info.html',data)
	
	
def add_category(request):
	
	data = {}
	if request.method == 'POST':
		form = Category_form(request.POST)
	else:
		form = Category_form()
	return s_obj.save_category_form(request, form, 'onboard/forms/add_category.html',-1)

	
def update_category(request, pk):
	category = get_object_or_404(CategoryData, pk=pk)
	if request.method == 'POST':
		form = Category_form(request.POST, instance=category)
	else:
		form = Category_form(instance=category)
	return s_obj.save_category_form(request, form, 'onboard/forms/partial_category_update.html',category.category_id)
	
	
def delete_category(request, pk):
	category = get_object_or_404(CategoryData, pk=pk)
	data = dict()
	if request.method == 'POST':
		category.delete()
		data['message'] = 'Category Deleted.'
		data['form_is_valid'] = True  # This is just to play along with the existing code
	else:
		context = {'category_obj': category}
		data['html_form'] = render_to_string('onboard/forms/partial_category_delete.html',
            context,
            request=request,
        )
	return JsonResponse(data)

	
def onboard_category_data_json(request):
	mod = 'All'
	if mod == "All":
		upoad_obj = CategoryData.objects.all().order_by('-category_id')
		data = []
		obj_count = 1
		for obj in upoad_obj:
			data.append(obj.category_data_json(obj_count))
			obj_count += 1
		response = {'data':data}
	return JsonResponse(response)	

				
#automation
def automation_info(request):
	'''
		Add Automation informations and view Automation informations
	'''
	data = dict()
	data['menu'] = {'area':'true','onboard':'active','acc':'','dash':'','os':'','ac':'','am':'active','sla':'','ta':'','du':'','emp':'','editacc':'','areas':'false'}
	return render(request, 'onboard/automation_info.html',data)
	
	
def add_automation(request):
	
	data = {}
	if request.method == 'POST':
		form = Automation_method_form(request.POST)
	else:
		form = Automation_method_form()
	return s_obj.save_automation_form(request, form, 'onboard/forms/add_automation.html',-1)

	
def update_automation(request, pk):
	automation = get_object_or_404(AutomationMethodData, pk=pk)
	if request.method == 'POST':
		form = Automation_method_form(request.POST, instance=automation)
	else:
		form = Automation_method_form(instance=automation)
	return s_obj.save_automation_form(request, form, 'onboard/forms/partial_automation_update.html',automation.automation_id)
	
	
def delete_automation(request, pk):
	automation = get_object_or_404(AutomationMethodData)
	data = dict()
	if request.method == 'POST':
		automation.delete()
		data['message'] = 'Automation Deleted.'
		data['form_is_valid'] = True  # This is just to play along with the existing code
	else:
		context = {'automation_obj': automation}
		data['html_form'] = render_to_string('onboard/forms/partial_automation_delete.html',
            context,
            request=request,
        )
	return JsonResponse(data)

	
def onboard_automation_data_json(request):
	mod = 'All'
	if mod == "All":
		upoad_obj = AutomationMethodData.objects.all().order_by('-automation_id')
		data = []
		obj_count = 1
		for obj in upoad_obj:
			data.append(obj.automationmethoddata_data_json(obj_count))
			obj_count += 1
		response = {'data':data}
	return JsonResponse(response)
				
#sla
def sla_info(request):
	'''
		Add SLA informations and view SLA informations
	'''
	data = dict()
	data['menu'] = {'area':'true','onboard':'active','acc':'','dash':'','os':'','ac':'','am':'','sla':'active','ta':'','du':'','emp':'','editacc':'','areas':'false'}
	return render(request, 'onboard/sla_info.html',data)
	
	
def add_sla(request):
	
	data = {}
	if request.method == 'POST':
		form = SLA_form(request.POST)
	else:
		form = SLA_form()
	return s_obj.save_sla_form(request, form, 'onboard/forms/add_sla.html',-1)

	
def update_sla(request, pk):
	sla = get_object_or_404(SLAData, pk=pk)
	if request.method == 'POST':
		form = SLA_form(request.POST, instance=sla)
	else:
		form = SLA_form(instance=sla)
	return s_obj.save_sla_form(request, form, 'onboard/forms/partial_sla_update.html',sla.sla_id)
	
	
def delete_sla(request, pk):
	sla = get_object_or_404(SLAData, pk=pk)
	data = dict()
	if request.method == 'POST':
		sla.delete()
		data['message'] = 'SLA Deleted.'
		data['form_is_valid'] = True  # This is just to play along with the existing code
	else:
		context = {'sla_obj': sla}
		data['html_form'] = render_to_string('onboard/forms/partial_sla_delete.html',
            context,
            request=request,
        )
	return JsonResponse(data)

	
def onboard_sla_data_json(request):
	mod = 'All'
	if mod == "All":
		upoad_obj = SLAData.objects.all().order_by('-sla_id')
		data = []
		obj_count = 1
		for obj in upoad_obj:
			data.append(obj.SLA_data_json(obj_count))
			obj_count += 1
		response = {'data':data}
	return JsonResponse(response) 


def emr_info(request):
	data = dict()
	data['menu'] = {'area':'false','onboard':'','acc':'','dash':'','os':'','ov':'','ac':'','sla':'','am':'','du':'','emp':'','editacc':'','areas':'false','emr':'active'}
	
	return render(request, 'EMR/emr_info.html',data)

def upload_masterfile(request):
	data = {}
	data['menu'] = {'area':'false','onboard':'','acc':'','dash':'','os':'','ov':'','ac':'','sla':'','am':'','du':'','emp':'','editacc':'','areas':'false','emr':'active'}
	if request.method == 'POST':
		form = EmrUploadForm(request.POST, request.FILES)
		if form.is_valid():
			e_obj.emr_upload_data(form,request)	
			return redirect('upload_masterfile')
	else:
		form = EmrUploadForm()
	upload_obj = EmrUpload.objects.all().order_by('id')
	data["form"] = form
	data["upoad_obj"] = upload_obj
	return render(request, 'EMR/emr_upload.html',data)

def onboard_EMR_data_json(request):
	mod = 'All'
	if mod == "All":
		upoad_obj = EMR.objects.filter(Q(TOWER='CIS-Unix-Admin')).order_by('index')
		data = []
		print(upoad_obj)
		obj_count = 1
		for obj in upoad_obj:
			data.append(obj.EMR_data_json(obj_count))
			obj_count += 1
		response = {'data':data}
	return JsonResponse(response) 
	
def load_account_info(request):	
	data = {}
	if request.method == 'POST':
		account_name = request.POST.get('acc_name')
		data["acc_data"] = acc_obj.get_account_data(request,account_name)
		data["server_data"] = acc_obj.get_server_data(request,account_name)
		data["tool_data"] = acc_obj.get_tool_data(request,account_name)
		data["risk_data"] = acc_obj.get_risk_data(request,account_name)
		data["sla_data"] = acc_obj.get_sla_data(request,account_name)
		data["tsg_data"] = acc_obj.get_tsg_data(request,account_name)
		data["automation_data"] = acc_obj.get_automation_data(request,account_name)
		data["doc_data"] = acc_obj.get_doc_data(request,account_name)
		data["employee_data"] = acc_obj.get_employee_data(request,'NiSource')
	else:
		data['message'] = 'Invalid account'
	return JsonResponse(data)

def load_account_info_edit(request):	
	data = {}
	if request.method == 'POST':
		account_name = request.POST.get('acc_name')
		data["acc_data"] = acc_obj.get_account_edit_data(request,account_name)
		data["server_data"] = acc_obj.get_server_edit_data(request,account_name)
		data["tool_data"] = acc_obj.get_tool_edit_data(request,account_name)
		data["risk_data"] = acc_obj.get_risk_edit_data(request,account_name)
		data["sla_data"] = acc_obj.get_sla_edit_data(request,account_name)
		data["tsg_data"] = acc_obj.get_tsg_edit_data(request,account_name)
		data["automation_data"] = acc_obj.get_automation_edit_data(request,account_name)
		data["doc_data"] = acc_obj.get_doc_edit_data(request,account_name)
	else:
		data['message'] = 'Invalid account'
	return JsonResponse(data)	
	
def logout_view(request):
    logout(request)
    return redirect('login_auth')
