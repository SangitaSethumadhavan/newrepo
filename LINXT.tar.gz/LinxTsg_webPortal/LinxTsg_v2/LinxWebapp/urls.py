from django.conf.urls import include, url
from LinxWebapp import views
from django.conf import settings
from django.conf.urls.static import static

 
urlpatterns = [
				url(r'^$', views.linxtsg_login_view, name='login_auth'),				
				url(r'^access_request$',views.linxtsg_access_request_view, name='access_request'),
				url(r'^Linux_dashboard$',views.linuxdashboard, name='Linux_dashboard'),
				url(r'^Access_approval$',views.access_approval, name='Access_approval'),
				url(r'^Access_approval/approval$',views.access_request_approval_json, name='access_request_approval'),
				url(r'^Access_approval/(?P<pk>\d+)/update/$', views.update_access_request, name='update_access_request'),	
				url(r'^Access_approval/(?P<pk>\d+)/delete/$', views.delete_user_request, name='delete_user_request'),	
				url(r'^Access_approval/(?P<pk>\d+)/approve/$', views.approve_user_request, name='approve_user_request'),	
				
				# Urls for Accounts Info
				url(r'^Linux/Accounts/Info$',views.linuxaccountinformation, name='Linux_Accounts_Info'),
				url(r'^Linux/Accounts/change/Info$',views.change_account_information, name='change_acc_infos'),
				url(r'^ajax/get_flavours/$',views.get_os_flavours, name='get_os_flavours'),	 
				url(r'^ajax/get_os_versions/$',views.get_os_versions, name='get_os_versions'),	 
				url(r'^ajax/save_server_info/$',views.save_server_informations, name='save_server_info'),	 
				url(r'^ajax/save_risk_info/$',views.save_risk_informations, name='save_risk_info'),	 
				url(r'^ajax/save_sla_info/$',views.save_sla_informations, name='save_sla_info'),	 
				url(r'^ajax/save_auto_info/$',views.save_automation_informations, name='save_auto_info'),	 
				url(r'^ajax/upload_tsg_file/$',views.upload_tsgassess_file, name='upload_tsgassess'),	 
				url(r'^ajax/upload_document_file/$',views.upload_document_file, name='upload_acc_document'),	 
				url(r'^ajax/save_account_info/$',views.save_account_informations, name='save_account_info'),	 
				 
				# Os Info
				url(r'^os_info$',views.os_info, name='os_info'),	
				url(r'^os_info/add_os/$', views.add_os, name='add_os'),	
				url(r'^os_info/(?P<pk>\d+)/update/$', views.update_os, name='update_os'),	
				url(r'^os_info/(?P<pk>\d+)/delete/$', views.delete_os, name='delete_os'),		
				url(r'^os_info/getosdata/$', views.onboard_os_data_json, name='onboard_os_data_json'),
				
				# OS Varient Info
				url(r'^os_varient_info$',views.os_varient_info, name='os_varient_info'),	
				url(r'^os_varient_info/add_os/$', views.add_os_varient, name='add_os_varient'),	
				url(r'^os_varient_info/(?P<pk>\d+)/update/$', views.update_os_varient, name='update_os_varient'),	
				url(r'^os_varient_info/(?P<pk>\d+)/delete/$', views.delete_os_varient, name='delete_os_varient'),		
				url(r'^os_varient_info/getosvarientdata/$', views.onboard_os_varient_data_json, name='onboard_os_varient_data_json'),
				
				#Category
				url(r'^category_info$',views.category_info, name='category_info'),	
				url(r'^category_info/add_category/$', views.add_category, name='add_category'),	
				url(r'^category_info/(?P<pk>\d+)/update/$', views.update_category, name='update_category'),	
				url(r'^category_info/(?P<pk>\d+)/delete/$', views.delete_category, name='delete_category'),		
				url(r'^category_info/getcategorydata/$', views.onboard_category_data_json, name='onboard_category_data_json'),
				
				#automation
				url(r'^automation_info$',views.automation_info, name='automation_info'),	
				url(r'^automation_info/add_automation/$', views.add_automation, name='add_automation'),	
				url(r'^automation_info/(?P<pk>\d+)/update/$', views.update_automation, name='update_automation'),	
				url(r'^automation_info/(?P<pk>\d+)/delete/$', views.delete_automation, name='delete_automation'),		
				url(r'^automation_info/getautomationdata/$', views.onboard_automation_data_json, name='onboard_automation_data_json'),
				 
				#sla
				url(r'^sla_info$',views.sla_info, name='sla_info'),	
				url(r'^sla_info/add_sla/$', views.add_sla, name='add_sla'),	
				url(r'^sla_info/(?P<pk>\d+)/update/$', views.update_sla, name='update_sla'),	
				url(r'^sla_info/(?P<pk>\d+)/delete/$', views.delete_sla, name='delete_sla'),		
				url(r'^sla_info/getsladata/$', views.onboard_sla_data_json, name='onboard_sla_data_json'),
							
				#EMR
				url(r'^emr_info$',views.emr_info, name='emr_info'),
				url(r'^emr_info/masterupload$', views.upload_masterfile, name='upload_masterfile'),
				url(r'^emr_info/load_account_info$', views.load_account_info, name='load_account_info'),
				url(r'^emr_info/load_account_info_edit$', views.load_account_info_edit, name='load_account_info_edit'),
				url(r'^emr_info/getemrdata/$', views.onboard_EMR_data_json, name='onboard_emr_data_json'),
				
				url(r'^logout$',views.logout_view, name='logout_view'),	  
			]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)