# -*- coding: utf-8 -*-
"""
	All operations related to Accounts 
"""
from __future__ import unicode_literals
from LinxWebapp.models import *
from LinxWebapp.forms import *
from django.db.models import Q
from datetime import datetime
from django.http import *
from django.shortcuts import render_to_response,redirect,get_object_or_404
from django.template.loader import render_to_string
import pandas as pd
from sqlalchemy import create_engine


class Account_management():
	'''
		acc_name
		acc_model
		acc_type
		acc_support_model
		acc_vertical
		acc_location
		acc_geo
		added_on
		added_by
	'''
	def __init__(self):
		pass
	
	def get_date(self):
		'''
			for current date 
		'''
		now = datetime.now()
		date = now.strftime("%Y-%m-%d")
		return date
		
	def save_account_form(self, request, form, template):
		'''
			Save Account info to AccountData
		'''
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				acc_name = form.cleaned_data['acc_name']
				acc_model = form.cleaned_data['acc_model']
				acc_type = form.cleaned_data['acc_type']
				acc_support_model = form.cleaned_data['acc_support_model']
				acc_vertical = form.cleaned_data['acc_vertical']
				acc_location = form.cleaned_data['acc_location']
				acc_geo = form.cleaned_data['acc_geo']
				added_by = request.session['uemail']
				data = {'is_taken': AccountData.objects.filter(acc_name=acc_name).exists()}
				if data['is_taken']:
					data['message'] = '"'+acc_name+'" is already exists.'
				else:
					model_obj = AccountData()
					model_obj.acc_name 			= acc_name 
					model_obj.acc_model 			= acc_model
					model_obj.acc_type			    = acc_type
					model_obj.acc_support_model	= acc_support_model
					model_obj.acc_vertical			= acc_vertical
					model_obj.acc_location			= acc_location	
					model_obj.acc_geo			    = acc_geo
					model_obj.added_on			    = self.get_date()
					model_obj.added_by			    = added_by
					model_obj.save()
					data['form_is_valid'] = True
					data['message'] = '"'+acc_name+'" Data added Successfully.'
					form = Account_form()
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['message'] = 'Invalid Data'
		context = {'form': form}
		data['account_add_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)		
		
	def upload_form(self, request, form, template):	
		'''
			Upload AccountData
		'''
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				file = request.FILES["uploaded_file"]
				uploaded_file_data = pd.read_excel(file,index=False)	
				self.upload_ata_to_db(request,file_data=uploaded_file_data)
				form.save()
				data['form_is_valid'] = True
				data['message'] = 'File Uploaded Successfully.'
				form = Account_upload_form() 
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data is'
		else:
			data['message'] = 'Invalid Data'
		context = {'form': form}
		data['account_upload_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)	
		
	def upload_ata_to_db(self,request,**kwargs): 
		'''
			Upload dataframe to db
		'''
		
		uploaded_file_data = kwargs['file_data']
		for index, row in uploaded_file_data.head().iterrows():
			data = dict()
			acc_name = row['Account Name']
			acc_model = row['Model']
			acc_type = row['Account Type']
			acc_support_model = row['Support Model']
			acc_vertical = row['Vertical']
			acc_location = row['Location']
			acc_geo = row['Geo']
			added_by = request.session['uemail']
			data = {'is_taken': AccountData.objects.filter(acc_name=acc_name).exists()}
			if data['is_taken']:
				model_obj = AccountData.objects.get(acc_name = acc_name)
			else:
				model_obj = AccountData()
			model_obj.acc_name 			= acc_name 
			model_obj.acc_model 			= acc_model
			model_obj.acc_type			    = acc_type
			model_obj.acc_support_model	= acc_support_model
			model_obj.acc_vertical			= acc_vertical
			model_obj.acc_location			= acc_location	
			model_obj.acc_geo			    = acc_geo
			model_obj.added_on			    = self.get_date()
			model_obj.added_by			    = added_by
			model_obj.save()
	
	def get_account_data(self,request,account_name):
		acc_obj = get_object_or_404(AccountData, acc_name=account_name)
		context = {'acc_obj': acc_obj}
		accdata = render_to_string('onboard/edit/account_data.html', context, request=request)
		return accdata
	
	def get_server_data(self,request,account_name):
		server_obj = ServerData.objects.filter(Q(acc_name=account_name))
		context = {'server_obj': server_obj}
		serverdata = render_to_string('onboard/edit/server_data.html', context, request=request)
		return serverdata
	
	def get_tool_data(self,request,account_name):
		tool_obj = get_object_or_404(ToolInfo, acc_name=account_name)
		context = {'tool_obj': tool_obj}
		tooldata = render_to_string('onboard/edit/tool_data.html', context, request=request)
		return tooldata
	
	def get_risk_data(self,request,account_name):
		risk_obj = RiskRegister.objects.filter(Q(acc_name=account_name))
		context = {'risk_obj': risk_obj}
		riskdata = render_to_string('onboard/edit/risk_data.html', context, request=request)
		return riskdata
	
	def get_sla_data(self,request,account_name):
		sla_obj = SLADataInfo.objects.filter(Q(acc_name=account_name))
		context = {'sla_obj': sla_obj}
		sladata = render_to_string('onboard/edit/sla_data.html', context, request=request)
		return sladata
	
	def get_automation_data(self,request,account_name):
		automation_obj = AutomationInfo.objects.filter(Q(acc_name=account_name))
		context = {'automation_obj': automation_obj}
		automationdata = render_to_string('onboard/edit/automation_data.html', context, request=request)
		return automationdata
		
	def get_tsg_data(self,request,account_name):
		tsg_obj = get_object_or_404(TsgAssessment, acc_name=account_name)
		tsg_table = TsgAssessUpload.objects.filter(Q(acc_name=account_name))
		context = {'tsg_obj': tsg_obj,'tsg_table':tsg_table}
		tsgdata = render_to_string('onboard/edit/tsg_data.html', context, request=request)
		return tsgdata
	def get_doc_data(self,request,account_name):
		doc_table = AccountDocumentUpload.objects.filter(Q(acc_name=account_name))
		context = {'doc_table': doc_table}
		docdata = render_to_string('onboard/edit/doc_data.html', context, request=request)
		return docdata
		
	def get_employee_data(self,request,account_name):
		emp_table = EMR.objects.filter(Q(GROUP_CUSTOMER_NAME=account_name) & Q(TOWER='CIS-Unix-Admin'))
		context = {'emp_table': emp_table}
		print(emp_table)
		empdata = render_to_string('onboard/edit/employee_data.html', context, request=request)
		return empdata	
	
	def get_account_edit_data(self,request,account_name):
		acc_obj = get_object_or_404(AccountData, acc_name=account_name)
		context = {'acc_obj': acc_obj}
		accdata = render_to_string('onboard/update/account_data.html', context, request=request)
		return accdata
	
	def get_server_edit_data(self,request,account_name):
		server_obj = ServerData.objects.filter(Q(acc_name=account_name))
		context = {'server_obj': server_obj}
		serverdata = render_to_string('onboard/update/server_data.html', context, request=request)
		return serverdata
	
	def get_tool_edit_data(self,request,account_name):
		tool_obj = get_object_or_404(ToolInfo, acc_name=account_name)
		context = {'tool_obj': tool_obj}
		tooldata = render_to_string('onboard/update/tool_data.html', context, request=request)
		return tooldata
	
	def get_risk_edit_data(self,request,account_name):
		risk_obj = RiskRegister.objects.filter(Q(acc_name=account_name))
		context = {'risk_obj': risk_obj}
		riskdata = render_to_string('onboard/update/risk_data.html', context, request=request)
		return riskdata
	
	def get_sla_edit_data(self,request,account_name):
		sla_obj = SLADataInfo.objects.filter(Q(acc_name=account_name))
		context = {'sla_obj': sla_obj}
		sladata = render_to_string('onboard/update/sla_data.html', context, request=request)
		return sladata
	
	def get_automation_edit_data(self,request,account_name):
		automation_obj = AutomationInfo.objects.filter(Q(acc_name=account_name))
		context = {'automation_obj': automation_obj}
		automationdata = render_to_string('onboard/update/automation_data.html', context, request=request)
		return automationdata
		
	def get_tsg_edit_data(self,request,account_name):
		tsg_obj = get_object_or_404(TsgAssessment, acc_name=account_name)
		tsg_table = TsgAssessUpload.objects.filter(Q(acc_name=account_name))
		context = {'tsg_obj': tsg_obj,'tsg_table':tsg_table}
		tsgdata = render_to_string('onboard/update/tsg_data.html', context, request=request)
		return tsgdata
	def get_doc_edit_data(self,request,account_name):
		doc_table = AccountDocumentUpload.objects.filter(Q(acc_name=account_name))
		context = {'doc_table': doc_table}
		docdata = render_to_string('onboard/update/doc_data.html', context, request=request)
		return docdata
		

acc_obj = Account_management()