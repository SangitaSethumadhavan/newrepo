# -*- coding: utf-8 -*-
"""
	All operations related to Admin section for input OS,OS Version,SLA Types,Automation Category,Automation Methods
"""
from __future__ import unicode_literals
from LinxWebapp.models import *
from LinxWebapp.forms import *
from django.db.models import Q
from datetime import datetime
from django.http import *
from django.template.loader import render_to_string
import pandas as pd
from sqlalchemy import create_engine


class OSManagement():

	def __init__(self):
		self.message = ''
	
	def get_date(self):
		'''
			for current date 
		'''
		now = datetime.now()
		date = now.strftime("%Y-%m-%d")
		return date 
	
	def save_os_form(self, request, form, template,mod):
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				if mod==-1:
					data = {'is_taken': OSData.objects.filter(os=form.cleaned_data['os'] ).exists()}
					if data['is_taken']:
						data['message'] = '"'+form.cleaned_data['os']+'" is already exists.'
						data['form_is_valid'] = False
					else:
						model_obj = OSData()
						model_obj.os 					= form.cleaned_data['os'] 
						model_obj.architecture 			= form.cleaned_data['architecture']
						model_obj.os_type 			= form.cleaned_data['os_type']
						model_obj.added_on			    = self.get_date()
						model_obj.added_by			    = request.session['uemail']
						model_obj.save()
						data['form_is_valid'] = True
						data['message'] = '"'+form.cleaned_data['os']+'" Data added Successfully.'
				else:					
					model_obj = OSData.objects.get(os_id=mod)
					model_obj.os 					= form.cleaned_data['os'] 
					model_obj.architecture 			= form.cleaned_data['architecture']
					model_obj.os_type 				= form.cleaned_data['os_type']
					model_obj.modified_on			    = self.get_date()
					model_obj.modified_by			    = request.session['uemail']
					model_obj.save()
					data['form_is_valid'] = True
					data['message'] = '"'+form.cleaned_data['os']+'" Data Updated Successfully.'
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['form_is_valid'] = False
			data['message'] = 'Failed form submition check the values'
		context = {'form': form}
		data['html_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)	
	
	def save_os_varient_form(self, request, form, template,mod):
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				os 					= form.cleaned_data['os'] 
				os_varient 			= form.cleaned_data['os_varient'] 
				varient_version 		= form.cleaned_data['varient_version'] 
				version_name		= os_varient +' '+ str(varient_version)
				if mod==-1:
					data = {'is_taken': OSVarient.objects.filter(version_name=version_name).exists()}
					if data['is_taken']:
						data['message'] = '"'+version_name+'" is already exists.'
						data['form_is_valid'] = False
					else:
						model_obj = OSVarient()
						model_obj.os 						= os
						model_obj.os_varient 				= os_varient
						model_obj.varient_version 			= varient_version
						model_obj.version_name 				= version_name
						model_obj.added_on			   		= self.get_date()
						model_obj.added_by			   		= request.session['uemail']
						model_obj.save()
						data['form_is_valid'] = True
						data['message'] = '"'+form.cleaned_data['os']+'" Data added Successfully.'
				else:					
					model_obj = OSVarient.objects.get(id=mod)
					model_obj.os 						= os
					model_obj.os_varient 				= os_varient
					model_obj.varient_version 			= varient_version
					model_obj.version_name 				= version_name
					model_obj.modified_on			    = self.get_date()
					model_obj.modified_by			    = request.session['uemail']
					model_obj.save()
					data['form_is_valid'] = True
					data['message'] = '"'+version_name+'" Data Updated Successfully.'
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['form_is_valid'] = False
			data['message'] = 'Failed form submition check the values'
		context = {'form': form}
		data['html_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)	
	
	def save_category_form(self, request, form, template,mod):
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				if mod==-1:
					data = {'is_taken': CategoryData.objects.filter(category=form.cleaned_data['category'] ).exists()}
					if data['is_taken']:
						data['message'] = '"'+form.cleaned_data['category']+'" is already exists.'
						data['form_is_valid'] = False
					else:
						model_obj = CategoryData()
						model_obj.category 					= form.cleaned_data['category'] 
						model_obj.added_on			    = self.get_date()
						model_obj.added_by			    = request.session['uemail']
						model_obj.save()
						data['form_is_valid'] = True
						data['message'] = '"'+form.cleaned_data['category']+'" Data added Successfully.'
				else:					
					model_obj 							= CategoryData.objects.get(category_id=mod)
					model_obj.category 					= form.cleaned_data['category'] 
					model_obj.modified_on			    = self.get_date()
					model_obj.modified_by			    = request.session['uemail']
					model_obj.save()
					data['form_is_valid'] = True
					data['message'] = '"'+form.cleaned_data['category']+'" Data Updated Successfully.'
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['form_is_valid'] = False
			data['message'] = 'Failed form submition check the values'
		context = {'form': form}
		data['html_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)
						
	def save_sla_form(self, request, form, template,mod):
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				if mod==-1:
					data = {'is_taken': SLAData.objects.filter(sla=form.cleaned_data['sla'] ).exists()}
					if data['is_taken']:
						data['message'] = '"'+form.cleaned_data['sla']+'" is already exists.'
						data['form_is_valid'] = False
					else:
						model_obj = SLAData()
						model_obj.sla 					= form.cleaned_data['sla'] 
						model_obj.added_on			    = self.get_date()
						model_obj.added_by			    = request.session['uemail']
						model_obj.save()
						data['form_is_valid'] = True
						data['message'] = '"'+form.cleaned_data['sla']+'" Data added Successfully.'
				else:					
					model_obj 							= SLAData.objects.get(sla_id=mod)
					model_obj.sla 						= form.cleaned_data['sla'] 
					model_obj.modified_on			    = self.get_date()
					model_obj.modified_by			    = request.session['uemail']
					model_obj.save()
					data['form_is_valid'] = True
					data['message'] = '"'+form.cleaned_data['sla']+'" Data Updated Successfully.'
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['form_is_valid'] = False
			data['message'] = 'Failed form submition check the values'
		context = {'form': form}
		data['html_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)	
					
	def save_automation_form(self, request, form, template,mod):
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				if mod==-1:
					data = {'is_taken': AutomationMethodData.objects.filter(method=form.cleaned_data['method'] ).exists()}
					if data['is_taken']:
						data['message'] = '"'+form.cleaned_data['method']+'" is already exists.'
						data['form_is_valid'] = False
					else:
						model_obj = AutomationMethodData()
						model_obj.method 				= form.cleaned_data['method'] 
						model_obj.added_on			    = self.get_date()
						model_obj.added_by			    = request.session['uemail']
						model_obj.save()
						data['form_is_valid'] = True
						data['message'] = '"'+form.cleaned_data['method']+'" Data added Successfully.'
				else:					
					model_obj 							= AutomationMethodData.objects.get(sla_id=mod)
					model_obj.method 					= form.cleaned_data['method'] 
					model_obj.modified_on			    = self.get_date()
					model_obj.modified_by			    = request.session['uemail']
					model_obj.save()
					data['form_is_valid'] = True
					data['message'] = '"'+form.cleaned_data['method']+'" Data Updated Successfully.'
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['form_is_valid'] = False
			data['message'] = 'Failed form submition check the values'
		context = {'form': form}
		data['html_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)	
	
	def get_os_types(self):
		os_types = OSData.objects.order_by('os_type').values_list('os_type', flat = True).distinct()
		os_str = ''
		for os in os_types:
			os_str += os+','
		os_str = os_str[:-1]
		return os_str
	
	def get_sla_types(self):
		sla_types = SLAData.objects.order_by('sla').values_list('sla', flat = True).distinct()
		sla_str = ''
		for sla in sla_types:
			sla_str += sla+','
		sla_str = sla_str[:-1]
		return sla_str	
	
	def get_solution_category(self):
		sc = CategoryData.objects.order_by('category').values_list('category', flat = True).distinct()
		sc_str = ''
		for s in sc:
			sc_str += s+','
		sc_str = sc_str[:-1]
		return sc_str	
	
	def get_automation_method(self):
		au_meth = AutomationMethodData.objects.order_by('method').values_list('method', flat = True).distinct()
		sc_str = ''
		for s in au_meth:
			sc_str += s+','
		sc_str = sc_str[:-1]
		return sc_str	
		
	def get_os_flavour(self,os_type):
		os_flavour = OSData.objects.filter(os_type=os_type).order_by('os').values_list('os', flat = True).distinct()
		flavour_list = []
		for flvr in os_flavour:
			flavour_list.append(flvr)
		return flavour_list
	
	def get_os_version(self,os):
		os_version = OSVarient.objects.filter(os=os).order_by('version_name').values_list('version_name', flat = True).distinct()
		version_list = []
		for flvr in os_version:
			version_list.append(flvr)
		return version_list
	
	def save_server_info(self,request):
		if request.method == 'POST':
			acc_name = request.POST.get('acc_name')
			os_type = request.POST.get('os_type')
			os_flavour = request.POST.get('os_flavour')
			os_vesrion = request.POST.get('os_vesrion')
			s_count = request.POST.get('s_count')
			data = {'is_taken': ServerData.objects.filter(Q(acc_name=acc_name) & Q(os=os_flavour) & Q(version_name=os_vesrion)).exists()}
			if data['is_taken']:
				id_obj = ServerData.objects.filter(Q(acc_name=acc_name) & Q(os=os_flavour) & Q(version_name=os_vesrion))
				id_val = 0
				for i in id_obj:
					id_val = i.s_id
				ser_obj = ServerData.objects.get(s_id=id_val)
				ser_obj.acc_name			= acc_name
				ser_obj.os 					= os_flavour 
				ser_obj.version_name 		= os_vesrion
				ser_obj.os_type 				= os_type
				ser_obj.server_count 		= s_count
				ser_obj.added_on 			= self.get_date()
				ser_obj.added_by 			= request.session['uemail']
				ser_obj.modified_on 			= self.get_date()
				ser_obj.modified_by			= request.session['uemail']
				ser_obj.save()
				self.message  = 'updated'
			else:
				ser_obj 					= ServerData()
				ser_obj.acc_name			= acc_name
				ser_obj.os 					= os_flavour 
				ser_obj.version_name 		= os_vesrion
				ser_obj.os_type 				= os_type
				ser_obj.server_count 		= s_count
				ser_obj.added_on 			= self.get_date()
				ser_obj.added_by 			= request.session['uemail']
				ser_obj.modified_on 			= self.get_date()
				ser_obj.modified_by			= request.session['uemail']
				ser_obj.save()
				self.message  = 'data updated'
		else:
			self.message  = 'Form Error'
		return self.message
		
	def save_risk_info(self,request):
		if request.method == 'POST':
			acc_name = request.POST.get('acc_name')
			risk = request.POST.get('risk')
			identified_date = request.POST.get('identified_date')
			closuredate = request.POST.get('closuredate')
			status = request.POST.get('status')
			remarks = request.POST.get('remarks')
			data = {'is_taken': RiskRegister.objects.filter(Q(acc_name=acc_name) & Q(risk_info=risk) & Q(identified_date=identified_date) & Q(closure_date=closuredate) & Q(status=status)).exists()}
			if data['is_taken']:
				id_obj = RiskRegister.objects.filter(Q(acc_name=acc_name) & Q(risk_info=risk) & Q(identified_date=identified_date) & Q(closure_date=closuredate) & Q(status=status))
				id_val = 0
				for i in id_obj:
					id_val = i.risk_id
				risk_obj = RiskRegister.objects.get(risk_id=id_val)
				risk_obj.acc_name			= acc_name
				risk_obj.risk_info			= risk 
				risk_obj.identified_date 		= identified_date
				risk_obj.closure_date 		= closuredate
				risk_obj.status 				= status
				risk_obj.remarks 			= remarks
				risk_obj.added_on 			= self.get_date()
				risk_obj.added_by 			= request.session['uemail']
				risk_obj.modified_on 		= self.get_date()
				risk_obj.modified_by			= request.session['uemail']
				risk_obj.save()
				self.message  = 'updated'
			else:
				risk_obj 					= RiskRegister()
				risk_obj.acc_name			= acc_name
				risk_obj.risk_info			= risk 
				risk_obj.identified_date 		= identified_date
				risk_obj.closure_date 		= closuredate
				risk_obj.status 				= status
				risk_obj.remarks 			= remarks
				risk_obj.added_on 			= self.get_date()
				risk_obj.added_by 			= request.session['uemail']
				risk_obj.modified_on 		= self.get_date()
				risk_obj.modified_by			= request.session['uemail']
				risk_obj.save()
				self.message  = 'data updated'
		else:
			self.message  = 'Form Error'
		return self.message
		
	def save_sla_info(self,request):
		if request.method == 'POST':
			acc_name = request.POST.get('acc_name')
			sla = request.POST.get('sla')
			response_time = request.POST.get('response_time')
			resolution_time = request.POST.get('resolution_time')
			priority = request.POST.get('priority')
			remarks = request.POST.get('remarks')
			data = {'is_taken': SLADataInfo.objects.filter(Q(acc_name=acc_name) & Q(sla=sla) & Q(priority=priority) & Q(response_time=response_time) & Q(resolution_time=resolution_time)).exists()}
			if data['is_taken']:
				id_obj = SLADataInfo.objects.filter(Q(acc_name=acc_name) & Q(sla=sla) & Q(priority=priority) & Q(response_time=response_time) & Q(resolution_time=resolution_time))
				id_val = 0
				for i in id_obj:
					id_val = i.sla_id
				risk_obj = SLADataInfo.objects.get(sla_id=id_val)
				risk_obj.acc_name			= acc_name
				risk_obj.sla					= sla 
				risk_obj.response_time 		= response_time
				risk_obj.resolution_time 		= resolution_time
				risk_obj.priority 			= priority
				risk_obj.remarks 			= remarks
				risk_obj.added_on 			= self.get_date()
				risk_obj.added_by 			= request.session['uemail']
				risk_obj.modified_on 		= self.get_date()
				risk_obj.modified_by			= request.session['uemail']
				risk_obj.save()
				self.message  = 'updated'
			else:
				risk_obj 					= SLADataInfo()
				risk_obj.acc_name			= acc_name
				risk_obj.sla					= sla 
				risk_obj.response_time 		= response_time
				risk_obj.resolution_time 		= resolution_time
				risk_obj.priority 			= priority
				risk_obj.remarks 			= remarks
				risk_obj.added_on 			= self.get_date()
				risk_obj.added_by 			= request.session['uemail']
				risk_obj.modified_on 		= self.get_date()
				risk_obj.modified_by			= request.session['uemail']
				risk_obj.save()
				self.message  = 'data updated'
		else:
			self.message  = 'Form Error'
		return self.message
	
	def save_automation_info(self,request):
		if request.method == 'POST':
			acc_name = request.POST.get('acc_name')
			solution = request.POST.get('solution')
			s_category = request.POST.get('s_category')
			s_type = request.POST.get('s_type')
			status = request.POST.get('status')
			date_of_deploy = request.POST.get('date_of_deploy')
			data = {'is_taken': AutomationInfo.objects.filter(Q(acc_name=acc_name) & Q(solution=solution) & Q(s_category=s_category) & Q(s_type=s_type) & Q(status=status) & Q(date_of_deploy=date_of_deploy)).exists()}
			if data['is_taken']:
				id_obj = AutomationInfo.objects.filter(Q(acc_name=acc_name) & Q(solution=solution) & Q(s_category=s_category) & Q(s_type=s_type) & Q(status=status) & Q(date_of_deploy=date_of_deploy))
				id_val = 0
				for i in id_obj:
					id_val = i.au_id
				risk_obj = AutomationInfo.objects.get(au_id=id_val)
				risk_obj.acc_name			= acc_name
				risk_obj.solution				= solution 
				risk_obj.s_category 			= s_category
				risk_obj.s_type 				= s_type
				risk_obj.status 				= status
				risk_obj.date_of_deploy 		= date_of_deploy
				risk_obj.added_on 			= self.get_date()
				risk_obj.added_by 			= request.session['uemail']
				risk_obj.modified_on 		= self.get_date()
				risk_obj.modified_by			= request.session['uemail']
				risk_obj.save()
				self.message  = 'updated'
			else:
				risk_obj 					= AutomationInfo()
				risk_obj.acc_name			= acc_name
				risk_obj.solution				= solution 
				risk_obj.s_category 			= s_category
				risk_obj.s_type 				= s_type
				risk_obj.status 				= status
				risk_obj.date_of_deploy 		= date_of_deploy
				risk_obj.added_on 			= self.get_date()
				risk_obj.added_by 			= request.session['uemail']
				risk_obj.modified_on 			= self.get_date()
				risk_obj.modified_by			= request.session['uemail']
				risk_obj.save()
				self.message  = 'data updated'
		else:
			self.message  = 'Form Error'
		return self.message	
	
	def save_account_info(self,request):
		data = dict()
		if request.method == 'POST':
			acc_name = request.POST.get('acc_name')
			acc_model  			= request.POST.get('acc_model')
			acc_type 			= request.POST.get('acc_type')
			acc_s_model 			= request.POST.get('acc_s_model')
			acc_vertical  	 	= request.POST.get('acc_vertical')
			acc_location  		= request.POST.get('acc_location')
			acc_geo  			= request.POST.get('acc_geo')
			p_tool  				= request.POST.get('p_tool')
			patch_tool  			= request.POST.get('patch_tool')
			patch_m_tool  		= request.POST.get('patch_m_tool')
			conf_tool  			= request.POST.get('conf_tool')
			assess_date  		= request.POST.get('assess_date')
			assessor  			= request.POST.get('assessor')
			assess_remarks  		= request.POST.get('assess_remarks')
			acc_is_taken = AccountData.objects.filter(Q(acc_name=acc_name)).exists()
			tool_is_taken = ToolInfo.objects.filter(Q(acc_name=acc_name)).exists()
			tsg_is_taken = TsgAssessment.objects.filter(Q(acc_name=acc_name)).exists()
			if acc_is_taken and tool_is_taken and tsg_is_taken:	
				id_obj = AccountData.objects.filter(Q(acc_name=acc_name))
				d_val = 0
				for i in id_obj:
					id_val = i.acc_id
				acc_obj  					= AccountData.objects.get(acc_id=id_val)
				acc_obj.acc_name 			= acc_name
				acc_obj.acc_model 			= acc_model				
				acc_obj.acc_support_model 	= acc_s_model
				acc_obj.acc_type 			= acc_type
				acc_obj.acc_vertical		 	= acc_vertical
				acc_obj.acc_location 			= acc_location
				acc_obj.acc_geo	 			= acc_geo
				acc_obj.added_on 			= self.get_date()
				acc_obj.added_by 			= request.session['uemail']
				acc_obj.modified_on 			= self.get_date()
				acc_obj.modified_by			= request.session['uemail']
				acc_obj.save()
				id_obj = ToolInfo.objects.filter(Q(acc_name=acc_name))
				d_val = 0
				for i in id_obj:
					id_val = i.tool_id
				tool_obj 						= ToolInfo.objects.get(tool_id=id_val)
				tool_obj.acc_name 				= acc_name
				tool_obj.provisioning_tool 			= p_tool				
				tool_obj.patch_m_tool 			= patch_tool
				tool_obj.patch_management 		= patch_m_tool
				tool_obj.conf_tool		 			= conf_tool
				tool_obj.added_on 				= self.get_date()
				tool_obj.added_by 				= request.session['uemail']
				tool_obj.modified_on 				= self.get_date()
				tool_obj.modified_by				= request.session['uemail']
				tool_obj.save()
				id_obj = TsgAssessment.objects.filter(Q(acc_name=acc_name))
				d_val = 0
				for i in id_obj:
					id_val = i.t_id
				tsg_obj   						= TsgAssessment.objects.get(t_id=id_val)
				tsg_obj.acc_name 				= acc_name
				tsg_obj.assess_date 				= assess_date				
				tsg_obj.assessor 					= assessor
				tsg_obj.remarks 					= assess_remarks
				tsg_obj.added_on 				= self.get_date()
				tsg_obj.added_by 				= request.session['uemail']
				tsg_obj.modified_on 				= self.get_date()
				tsg_obj.modified_by				= request.session['uemail']
				tsg_obj.save()
				
				self.message  = 'Data inserted Successfully'
				data['form_is_valid'] = True
			else:
				acc_obj  					= AccountData()
				acc_obj.acc_name 			= acc_name
				acc_obj.acc_model 			= acc_model				
				acc_obj.acc_support_model 	= acc_s_model
				acc_obj.acc_type 			= acc_type
				acc_obj.acc_vertical		 	= acc_vertical
				acc_obj.acc_location 			= acc_location
				acc_obj.acc_geo	 			= acc_geo
				acc_obj.added_on 			= self.get_date()
				acc_obj.added_by 			= request.session['uemail']
				acc_obj.modified_on 			= self.get_date()
				acc_obj.modified_by			= request.session['uemail']
				acc_obj.save()
				
				tool_obj 						= ToolInfo()
				tool_obj.acc_name 				= acc_name
				tool_obj.provisioning_tool 			= p_tool				
				tool_obj.patch_m_tool 			= patch_tool
				tool_obj.patch_management 		= patch_m_tool
				tool_obj.conf_tool		 			= conf_tool
				tool_obj.added_on 				= self.get_date()
				tool_obj.added_by 				= request.session['uemail']
				tool_obj.modified_on 				= self.get_date()
				tool_obj.modified_by				= request.session['uemail']
				tool_obj.save()
				
				tsg_obj   						= TsgAssessment()
				tsg_obj.acc_name 				= acc_name
				tsg_obj.assess_date 				= assess_date				
				tsg_obj.assessor 					= assessor
				tsg_obj.remarks 					= assess_remarks
				tsg_obj.added_on 				= self.get_date()
				tsg_obj.added_by 				= request.session['uemail']
				tsg_obj.modified_on 				= self.get_date()
				tsg_obj.modified_by				= request.session['uemail']
				tsg_obj.save()
				
				self.message  = 'Data inserted Successfully'
				data['form_is_valid'] = True
		else:
			self.message  = 'Form Error'
			data['form_is_valid'] = False
		
		data['message'] = self.message
		return data
	
	def save_upload_tsgassess_form(self, request, form, template):
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				acc_name = form.cleaned_data['acc_name']
				form.save()
				file_details = TsgAssessUpload.objects.filter(acc_name=acc_name).order_by('-id')
				s_dict = {'file_details': file_details}
				data['tsg_table'] = render_to_string('onboard/list/tsg_upload_table.html', s_dict, request=request)
				data['form_is_valid'] = True
				data['message'] = 'File Uploaded'
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['form_is_valid'] = False
			data['message'] = 'Failed form submition check the values'
		context = {'form': form}
		data['html_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)	
		
	def save_upload_document_form(self, request, form, template):
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				acc_name = form.cleaned_data['acc_name']
				form.save()
				file_details = AccountDocumentUpload.objects.filter(acc_name=acc_name).order_by('-id')
				s_dict = {'file_details': file_details}
				data['doc_table'] = render_to_string('onboard/list/doc_upload_table.html', s_dict, request=request)
				data['form_is_valid'] = True
				data['message'] = 'File Uploaded'
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['form_is_valid'] = False
			data['message'] = 'Failed form submition check the values'
		context = {'form': form}
		data['html_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data)

s_obj = OSManagement()