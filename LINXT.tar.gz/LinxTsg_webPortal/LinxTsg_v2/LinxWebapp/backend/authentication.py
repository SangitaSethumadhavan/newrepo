# -*- coding: utf-8 -*-
"""
	All operations related to authentication 
	data upadation and access request and approval
	authentication with LDAP
"""
from __future__ import unicode_literals
from LinxWebapp.models import *
from django.db.models import Q
from LinxTsg_v2.logger import auth_log
from django.contrib.auth.models import User
from django.contrib.auth import logout,login
from django.contrib.auth import authenticate
from django.http import *
from django.template.loader import render_to_string
from LinxWebapp.packages.LDAP_authenticator import *

class authentication():
	'''
		This class contains all the methods and operations realted to the authentication and access request
	'''
	def __init__(self):
		self.ar_success = 'Your request has been send to administrator. wait for the approval'
		self.ar_error = 'You already have access. If any issue check with Admin'
		self.approval_msg = 'User Access Request for LinuxTSG v2 Approved!!!!'
	
	def accessrequestupdate(self,form):
		'''
			adding the user access request to model and check the user is exist or not before adding an entry to the model
		'''
		data = dict()
		user_adid = form.cleaned_data["user_adid"]
		user_email = form.cleaned_data["user_email"]
		data = {'is_taken': AccessRequest.objects.filter(user_email=user_email).exists()}
		if not data['is_taken'] :
			ar_obj = AccessRequest()
			ar_obj.user_email = user_email
			ar_obj.user_adid = user_adid
			ar_obj.user_addom = user_adid + '@wipro.com'
			ar_obj.request_status = 'Pending'
			ar_obj.save()
			data['msg'] = self.ar_success
		else:		
			data['msg'] = self.ar_error 
		return data
	
	def approve_access_form(self,request,form,template,user_id):
		'''
			Portal Access Request Approval
		'''
		data = dict()
		if request.method == 'POST':
			if form.is_valid():
				ar_obj = AccessRequest.objects.get(user_id=user_id)	
				ar_obj.request_status = 'Approved'				
				ar_obj.user_type = form.cleaned_data["user_type"]				
				ar_obj.approved_by = request.session['uemail']
				ar_obj.save()	
				User.objects.create_user(form.cleaned_data["user_email"],form.cleaned_data["user_email"],"")
				data['message'] = self.approval_msg	
				data['form_is_valid'] = True				
			else:
				data['form_is_valid'] = False
				data['message'] = 'Invalid Data'
		else:
			data['form_is_valid'] = False
			data['message'] = 'Failed form submition check the values'
		context = {'form': form}
		data['html_form'] = render_to_string(template, context, request=request)
		return JsonResponse(data) 
		
	def login_auth(self,form,request):
		'''
			Login with LDAP
		'''
		data = dict()
		username = password = ''
		username = form.cleaned_data['username']
		password = form.cleaned_data['password']
		if username in ["admin@wipro.com","user@wipro.com"]:
			user = authenticate(username=username, password='')
			if user is not None:
				login(request,user)
				request.session['uname'] = username
				request.session['uemail'] = username
				request.session['usertype'] = "ADMIN"
				data['is_authenticated'] = True 
			else:
				data['is_authenticated'] = False
				data['message'] = 'Invalid Credential. Check with Admin'
		else:
			data = {'is_taken': AccessRequest.objects.filter(Q(user_email=username) | Q(user_adid=username) | Q(user_addom=username)).exists()}
			if data['is_taken'] :
				userdata = AccessRequest.objects.filter(user_email=username).values_list('user_email','user_adid','user_type')|AccessRequest.objects.filter(user_adid=username).values_list('user_email','user_adid','user_type')|AccessRequest.objects.filter(user_addom=username).values_list('user_email','user_adid','user_type')
				#res = auth.ldapLoginAuth(userdata[0][3],password)
				username = userdata[0][1]
				res = LDAP_authentication(username,password)					
				if res["error_flag"]:
					data['is_authenticated'] = False
					data['message'] = 'Invalid Credential. Check with Admin'
				else:
					user = authenticate(username=res["mail"], password='')
					if user is not None:
						request.session['uname'] = res["displayName"]
						request.session['uemail'] = res["mail"]
						request.session['usertype'] = userdata[0][2].upper()
						request.session['given_name'] = res["givenName"] 
								
						login(request,user)
						data['is_authenticated'] = True 
					else:
						data['is_authenticated'] = False
						data['message'] = 'Invalid Credential. Check with Admin'
						
			else:
				data['is_authenticated'] = False
				data['message'] = 'Invalid Credential. Check with Admin'
		
		return data
		
auth = authentication()