# -*- coding: utf-8 -*-
"""
	All operations related to EMR
"""
from __future__ import unicode_literals
from LinxWebapp.models import *
from LinxWebapp.forms import *
from django.db.models import Q
from datetime import datetime
from django.http import *
from django.template.loader import render_to_string
import pandas as pd
from sqlalchemy import create_engine
from django.utils import timezone
from django.conf import settings

class EMRManagement():
	
	def __init__(self):
		self.message = ''
		
	def get_date(self):
		'''
			for current date 
		'''
		now = datetime.now()
		date = now.strftime("%Y-%m-%d")
		return date 
	
	def emr_upload_data(self,form,request):	
		file = request.FILES["uploaded_file"]
		uploaded_file_data = pd.read_excel(file,sheet_name='MASTER')

		uploaded_file_data.rename(columns={'EMP_CODE'					:'EMP_CODE',
										'EMP_NAME'						:'EMP_NAME',
										'FRESHER_INDEX'					:'FRESHER_INDEX', 
										'DERIVED_SUITE_NAME'			:'DERIVED_SUITE_NAME',
										'ROOKIE_STATUS'					:'ROOKIE_STATUS',
										'HOME_COMPANY_CODE'				:'HOME_COMPANY_CODE',
										'DERIVED_EMP_COUNTRY'			:'DERIVED_EMP_COUNTRY',
										'COSTCTR'						:'COSTCTR',
										'CAREER_BAND'					:'CAREER_BAND',
										'EMPLOYEE_EMAIL_ID'				:'EMPLOYEE_EMAIL_ID',
										'LOCATION'						:'LOCATION',
										'BENCH STATUS'					:'BENCH_STATUS',
										'SELECTED / ALLOCATED ACCOUNT'	:'SELECTED_ALLOCATED_ACCOUNT',
										'REMARKS'						:'REMARKS',
										'AREA'							:'AREA',
										'SAP_BU_DESC'					:'SAP_BU_DESC',
										'VERTICAL'						:'VERTICAL',
										'GROUP_CUSTOMER_NAME'			:'GROUP_CUSTOMER_NAME',
										'PROJECT_CODE'					:'PROJECT_CODE',
										'PROJ_TENURE'					:'PROJ_TENURE',
										'CUST_TENURE'					:'CUST_TENURE',
										'PRACTICE'						:'PRACTICE',
										'PRAC_CC_DESC'					:'PRAC_CC_DESC',
										'DATE_OF_JOINING'				:'DATE_OF_JOINING',
										'EXPERIENCE'					:'EXPERIENCE',
										'PRIMARY_SUPERVISOR'			:'PRIMARY_SUPERVISOR',
										'PROJECT_SUPERVISOR'			:'PROJECT_SUPERVISOR',
										'PROJECT_SUPERVISOR_MAIL ID'	:'PROJECT_SUPERVISOR_MAIL_ID',
										'FLEXPROJ'						:'FLEXPROJ',
										'Sum of Billable'				:'Sum_of_Billable',
										'Sum of Non Billable'			:'Sum_of_Non_Billable',
										'Sum of Support'				:'Sum_of_Support',
										'Sum of Free'					:'Sum_of_Free',
										'Sum of TOTAL_DAYS'				:'Sum_of_TOTAL_DAYS',
										'Status'						:'Status',
										'NB Ageing'						:'NB_Ageing',
										'NB Age Category'				:'NB_Age_Category',
										'RD Date'						:'RD_Date',
										'RAMP DOWN'						:'RAMP_DOWN',
										'RD Account'					:'RD_Account',
										'RD Ageing'						:'RD_Ageing',
										'RD VERTICAL'					:'RD_VERTICAL',
										'INVESTED_TO'					:'INVESTED_TO',
										'LEAVE_STAT'					:'LEAVE_STAT',
										'DERIVED_SUITE_ID'				:'DERIVED_SUITE_ID',
										'DERIVED_SUITE_NAME'			:'DERIVED_SUITE_NAME',
										'TOWER'							:'TOWER',
										'TOWER_1'						:'TOWER_1',
										'LEVEL'							:'LEVEL',
										'CERTIFITED SKILL'				:'CERTIFITED_SKILL',
										'UNASSESSED_SKILL'				:'UNASSESSED_SKILL',
										'TRAINING_SKILLS'				:'TRAINING_SKILLS',
										'PROJECT_ACQUIRED_SKILL'		:'PROJECT_ACQUIRED_SKILL',
										'PROJ_TYPE'						:'PROJ_TYPE',
										'ONS_OFF_FLAG'					:'ONS_OFF_FLAG',
										'RTR_STATUS'					:'RTR_STATUS',
										'ESSENTIAL_SKILL'				:'ESSENTIAL_SKILL',
										'INDENT_ROLE_ID'				:'INDENT_ROLE_ID',
										'INDENT_ROLE_DESC'				:'INDENT_ROLE_DESC',
										'DU_PRACTICE'					:'DU_PRACTICE',
										'COMPANY_IDENTIFICATION_FG'		:'COMPANY_IDENTIFICATION_FG',
										'MODEL'							:'MODEL',
										'WIPRO_EXP'						:'WIPRO_EXP',
										},
										inplace=True)

		uploaded_file_data["added_on"] = self.get_date()
		uploaded_file_data["added_by"] = request.session['uname']
		uploaded_file_data.drop_duplicates(subset ="EMP_CODE", 
                     keep = 'first', inplace = True) 
		EMR.objects.all().delete()			
		dbuser = settings.DATABASES['default']['USER']
		dbpswd = settings.DATABASES['default']['PASSWORD']
		dbname = settings.DATABASES['default']['NAME'] 
		dbhost = ''
		engine = create_engine("mysql+pymysql://{user}:{pw}@localhost/{db}".format(user=dbuser,pw=dbpswd,db=dbname),pool_recycle=1)

		uploaded_file_data.to_sql(con=engine, name='LT_EMR', if_exists='append')
		form.save()
		
e_obj = EMRManagement()